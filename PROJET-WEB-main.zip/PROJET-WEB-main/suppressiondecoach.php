<?php
    //identifier votre BDD
$database = "projet";
    //identifier votre serveur (localhost), utlisateur (root), mot de passe ("")
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);
$Email = isset($_POST["Email"]) ? $_POST["Email"] : "";

if ($db_found) {
    $sql = "DELETE FROM `coach` WHERE `mail` = '$Email'";
    $result = mysqli_query($db_handle, $sql);
    $sql = "DELETE FROM `users` WHERE `Email` = '$Email'";
    $result = mysqli_query($db_handle, $sql);
    $sql = "DELETE FROM `disponibilite` WHERE `ID_Coach` = '$Email'";
    $result = mysqli_query($db_handle, $sql);
    header("Location: pageadmin.php");

    } // end if
    else {
        echo "database not found";
    }
    mysqli_close($db_handle);
?>