<?php
// Start the session
session_start();

?>

<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- FICHIER CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="accueil.css">
	<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<!-- FICHIER JS -->
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
	<title>Sportify : Consultation Sportive</title>
	<link rel="icon" href="onglet.png" type="image/x-icon">
	<link rel="shortcut icon" href="onglet.png" type="image/x-icon">
	<script type="text/javascript">
		$(document).ready(function () {
			$('.header').height($(window).height());
		});
	</script>
	<script type="text/javascript">
		function scrollToSection(sectionId) {
			const section = document.querySelector(`#${sectionId}`);
			window.scrollTo({
				top: section.offsetTop,
				behavior: 'smooth'
			});
		}
	</script>
    <!-- ANNIMATION DATE -->
	<style>
        
        body {
            
        }

        .heart-container { 
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 9999;
        }

        .heart {
            position: absolute;
            display: block;
            width: 30px;
            height: 30px;
            background: url('https://static.vecteezy.com/system/resources/thumbnails/018/842/695/small/red-heart-shape-icon-like-or-love-symbol-for-valentine-s-day-3d-render-illustration-free-png.png') no-repeat;
            background-size: contain;
            transform: scale(0);
            animation: fall linear infinite;
            animation-duration: 2s;
        }
        .snowflake-container {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 9999;
    }

    .snowflake {
        position: absolute;
        display: block;
        width: 30px;
        height: 30px;
        background: url('https://images.emojiterra.com/mozilla/512px/1f385.png') no-repeat;
        background-size: contain;
        transform: scale(0);
        animation: fall linear infinite;
        animation-duration: 4s;
    }
    .flag-container {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 9999;
    }

    .flag {
        position: absolute;
        display: block;
        width: 30px;
        height: 30px;
        background: url('https://images.emojiterra.com/mozilla/512px/1f1eb-1f1f7.png') no-repeat;
        background-size: contain;
        transform: scale(0);
        animation: fall linear infinite;
        animation-duration: 2s;
    }

        @keyframes fall {
            0% {
                transform: translate3d(calc(var(--startX) * 1vw), -10vh, 0) scale(0);
                opacity: 0;
            }
            100% {
                transform: translate3d(calc(var(--endX) * 1vw), 110vh, 0) scale(1);
                opacity: 1;
            }
        }
        
    </style>
	
</head>

<body class="pt-5">
 <div class="heart-container">
 	<!-- DATE POUR ANIM -->
        <script>
            // Récupère la date actuelle
            var currentDate = new Date();
            var currentMonth = currentDate.getMonth() + 1; // Mois actuel (ajout de 1 car les mois commencent à 0)
            var currentDay = currentDate.getDate(); // Jour actuel

            // Vérifie si c'est le 14 février (jour de la Saint-Valentin)
            if (currentMonth === 2 && currentDay === 14) {
                // Récupère la hauteur de la page
                var pageHeight = Math.max(
                    document.body.scrollHeight,
                    document.body.offsetHeight,
                    document.documentElement.clientHeight,
                    document.documentElement.scrollHeight,
                    document.documentElement.offsetHeight
                );

                // Crée un cœur et l'ajoute à la page
                function createHeart() {
                    var heart = document.createElement('span');
                    heart.classList.add('heart');
                    heart.style.setProperty('--startX', Math.random() * 100);
                    heart.style.setProperty('--endX', Math.random() * 100);
                    document.querySelector('.heart-container').appendChild(heart);

                    // Supprime le cœur après l'animation
                    heart.addEventListener('animationend', function () {
                        heart.parentNode.removeChild(heart);
                    });
                }

                // Fait tomber les cœurs en boucle
                setInterval(createHeart, 400); // Modifier le délai ici (en millisecondes)

                // Redimensionne les cœurs lorsque la fenêtre est redimensionnée
                window.addEventListener('resize', function () {
                    pageHeight = Math.max(
                        document.body.scrollHeight,
                        document.body.offsetHeight,
                        document.documentElement.clientHeight,
                        document.documentElement.scrollHeight,
                        document.documentElement.offsetHeight
                    );
                });
            }
        </script>
    </div>
    <div class="snowflake-container">
    	<script>
            if (currentMonth === 12 && currentDay === 25) {
            // Récupère la hauteur de la page
            var pageHeight = Math.max(
                document.body.scrollHeight,
                document.body.offsetHeight,
                document.documentElement.clientHeight,
                document.documentElement.scrollHeight,
                document.documentElement.offsetHeight
            );

            // Crée un flocon de neige et l'ajoute à la page
            function createSnowflake() {
                var snowflake = document.createElement('span');
                snowflake.classList.add('snowflake');
                snowflake.style.setProperty('--startX', Math.random() * 100);
                snowflake.style.setProperty('--endX', Math.random() * 100);
                document.querySelector('.snowflake-container').appendChild(snowflake);

                // Supprime le flocon de neige après l'animation
                snowflake.addEventListener('animationend', function () {
                    snowflake.parentNode.removeChild(snowflake);
                });
            }

            // Fait tomber les flocons de neige en boucle
            setInterval(createSnowflake, 800); // Modifier le délai 

            // Redimensionne les flocons de neige lorsque la fenêtre est redimensionnée
            window.addEventListener('resize', function () {
                pageHeight = Math.max(
                    document.body.scrollHeight,
                    document.body.offsetHeight,
                    document.documentElement.clientHeight,
                    document.documentElement.scrollHeight,
                    document.documentElement.offsetHeight
                );
            });
        }
    </script>
</div>
<div class="flag-container">
        <script>
        if (currentMonth === 7 && currentDay === 14) {
                // Récupère la hauteur de la page
                var pageHeight = Math.max(
                    document.body.scrollHeight,
                    document.body.offsetHeight,
                    document.documentElement.clientHeight,
                    document.documentElement.scrollHeight,
                    document.documentElement.offsetHeight
                );

                // Crée un drapeau et l'ajoute à la page
                function createFlag() {
                    var flag = document.createElement('span');
                    flag.classList.add('flag');
                    flag.style.setProperty('--startX', Math.random() * 100);
                    flag.style.setProperty('--endX', Math.random() * 100);
                    document.querySelector('.flag-container').appendChild(flag);

                    // Supprime le drapeau après l'animation
                    flag.addEventListener('animationend', function () {
                        flag.parentNode.removeChild(flag);
                    });
                }

                // Fait tomber les drapeaux en boucle
                setInterval(createFlag, 400); // Modifier le délai ici (en millisecondes)

                // Redimensionne les drapeaux lorsque la fenêtre est redimensionnée
                window.addEventListener('resize', function () {
                    pageHeight = Math.max(
                        document.body.scrollHeight,
                        document.body.offsetHeight,
                        document.documentElement.clientHeight,
                        document.documentElement.scrollHeight,
                        document.documentElement.offsetHeight
                    );
                });
            }
      


        </script>

    </div>
    
    

	<!-- BAR NAVIGATION -->
	<nav class="navbar navbar-expand-md fixed-top">
		<a class="navbar-brand" href="accueil.php">
			<!-- LOGO -->
			<img id="logo" src="logo.png" height="80" width="200" alt="logo">
		</a>
		<button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="main-navigation">
			<ul class="navbar-nav">
				<!-- MENU -->
				<li class="nav-item"><a class="nav-link" href="accueil.php"><b>Accueil</b></a></li>
				<li class="nav-item"><a class="nav-link" href="ToutParcourir.php"><b>Tout Parcourir</b></a></li>
				<li class="nav-item"><a class="nav-link" href="recherchetest.php"><b>Recherche</b></a></li>
				<li class="nav-item"><?php
                    if (isset($_SESSION["Role"])) {
                        if ($_SESSION["Role"] === "Coach") {
                            echo '<a class="nav-link" href="rendezvouscoach.php">';
                        } else if ($_SESSION["Role"] === "Admin") {
                            echo '<a class="nav-link" href="accueil.php">';
                        } else {
                            echo '<a class="nav-link" href="rendezvous.php">';
                        }
                    } else {
                        echo '<a class="nav-link" href="rendezvous.php">';
                    }
                    ?><b>Rendez-vous</b></a></li>
				<li class="nav-item2">
					<?php
					if (isset($_SESSION["Role"])) {
						if ($_SESSION["Role"] === "Client") {
							echo '<a class="compte" href="pageclient.php">';
						} else if ($_SESSION["Role"] === "Coach") {
							echo '<a class="compte" href="pagecoach.php">';
						} else if ($_SESSION["Role"] === "Admin") {
							echo '<a class="compte" href="pageadmin.php">';
						} else {
							echo '<a class="compte" href="compte.php">';
						}
					} else {
						echo '<a class="compte" href="compte.php">';
					}
					?>
					<strong>Mon compte</strong></a>
				</li>
			</ul>

		</div>
	</nav>
	<!-- HEADER -->
	<div class="accc">

		<header class="page-header header container-fluid" name="acc">
			<div class="overlay"></div>
			<div data-aos="fade-left" data-aos-duration="1000" class="description">
				<h1><strong>
						<span>LES RENDEZ-VOUS SPORTIFS SONT UNIQUE,</span>
						<br><br>
						VOTRE ENTRAINEMENT DOIT L'ETRE AUSSI !</strong></h1>

			</div>
		</header>
	</div>
	<!-- PRESENTTATION DE SPORTIFY -->
	<section class="presentation">
		<div class="container-fluid">
			<strong>
				<h2 style="text-align: center;">Bienvenue sur SPORTIFY</h2>
			</strong>
			<br><br>
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-12">
					<h3 data-aos="fade-up" data-aos-offset="200" data-aos-delay="500" data-aos-duration="1000"
						data-aos-easing="ease-in-out" data-aos-mirror="true" data-aos-once="false"
						data-aos-anchor-placement="top-center">SPORTIFY c'est :</h3>
					<br>
					<ul class="liste_web">
						<li>
							<p data-aos="fade-right" data-aos-offset="200" data-aos-delay="1000"
								data-aos-duration="1000" data-aos-easing="ease-in-out" data-aos-mirror="true"
								data-aos-once="false" data-aos-anchor-placement="top-center"><img alt="materiel"
									src="web.png" width="72" height="70">
								Un site web pour réserver en ligne des séances de coaching sportif.</p>
						</li>
						<li>
							<p data-aos="fade-right" data-aos-offset="200" data-aos-delay="1500"
								data-aos-duration="1000" data-aos-easing="ease-in-out" data-aos-mirror="true"
								data-aos-once="false" data-aos-anchor-placement="top-center"><img alt="materiel"
									src="diplome.png" width="72" height="72">
								Des coachs diplômés d'État pour vous accompagner.</p>
						</li>
						<li>
							<p data-aos="fade-right" data-aos-offset="200" data-aos-delay="2000"
								data-aos-duration="1000" data-aos-easing="ease-in-out" data-aos-mirror="true"
								data-aos-once="false" data-aos-anchor-placement="top-center"><img alt="materiel"
									src="fit.png" width="72" height="72">
								Des activités variées et des programmes exclusifs.</p>
						</li>
						<li>
							<p data-aos="fade-right" data-aos-offset="200" data-aos-delay="2500"
								data-aos-duration="1000" data-aos-easing="ease-in-out" data-aos-mirror="true"
								data-aos-once="false" data-aos-anchor-placement="top-center"><img alt="materiel"
									src="message.png" width="72" height="72">
								Communiquez avec les coachs via notre messagerie intégrée.</p>
						</li>
					</ul>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-12 position-relative" data-aos="zoom-in-left" data-aos-offset="300"
					data-aos-delay="50" data-aos-duration="1500" data-aos-easing="ease-in-out" data-aos-mirror="true"
					data-aos-once="false" data-aos-anchor-placement="top-center">
					<img src="presentation.png" width="500" height="500" style="border-radius: 10px;">
					<a href="rendezvous.php" class="Brdv position-absolute">Planifier un RDV</a>
				</div>
			</div>
		</div>
	</section>
	<!-- SECTION EVENEMENT -->
	<section class="evenement">
		<div class="container features">
			<h2 data-aos="fade-up" data-aos-delay="600" data-aos-duration="1000" data-aos-easing="ease-in-out"
				data-aos-mirror="true" data-aos-once="false" data-aos-anchor-placement="top-center">SPORTIFY C'EST AUSSI
				UN GRAND NOMBRE D'EVENEMENTS CHAQUE SEMAINE !</h2>
			<div class="row" style="text-align: center;">
				<p data-aos="fade-up" data-aos-delay="700" data-aos-duration="1000" data-aos-easing="ease-in-out"
					data-aos-mirror="true" data-aos-once="false" data-aos-anchor-placement="top-center" class="debut"
					style="padding: 20px;">Plus de <strong>60 heures</strong> de cours collectifs et individuels sont
					proposés chaque semaine dans nos clubs. En parallèle de ces cours, de <strong>nombreux
						événements</strong> ont lieu chaque semaine <em>(inauguration, porte ouverte,
						compétitions...).</em></p>

				<div class="col-lg-4 col-md-4 col-sm-12">
					<div data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1000" data-aos-easing="ease-in-out"
						data-aos-mirror="true" data-aos-once="false" data-aos-anchor-placement="top-center"
						class="d-flex flex-column align-items-center">
						<h5>Salle de fitness - CAMPUS EIFFEL</h5>
						<div class="thumbnail">
							<a href="https://static.observatoiredelafranchise.fr/images/ckfinder/images/2021/06/30/image-2cf670.png"
								target="_blank">
								<img src="https://static.observatoiredelafranchise.fr/images/ckfinder/images/2021/06/30/image-2cf670.png"
									style="border-radius: 4px;" class="img-fluid">
							</a>
							<p style="text-align: justify;">Cette semaine, l'ECE met à l'honneur l'innoguration de la
								nouvelle <strong>salle de Fitness au campus EFFEIL</strong>. L'occasion de venir
								découvrir les nouvelles machines et pouvoir échanger avec les coachs.</p>
						</div>

					</div>
				</div>
				<div data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1000" data-aos-easing="ease-in-out"
					data-aos-mirror="true" data-aos-once="false" data-aos-anchor-placement="top-center"
					class="col-lg-4 col-md-4 col-sm-12">
					<div class="d-flex flex-column align-items-center">
						<h5>24H ECE-Vélo</h5>
						<a href="velo.png" target="_blank">
							<img src="velo.png" style="border-radius: 4px;" class="img-fluid">
						</a>
						<p style="text-align: justify;">Ce Week-end, on lieu les <strong>24H ECE-Vélo</strong>. Un
							évènement tant attendu par tout les étudiants amateurs de cyclisme permettant de repousser
							ces limites !</p>
					</div>
				</div>

				<div data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1000" data-aos-easing="ease-in-out"
					data-aos-mirror="true" data-aos-once="false" data-aos-anchor-placement="top-center"
					class="col-lg-4 col-md-4 col-sm-12">
					<div class="d-flex flex-column align-items-center">
						<h5>Rencontre et cours de Judo avec Teddy Rinner</h5>
						<a href="https://www.francebleu.fr/s3/cruiser-production/2016/08/23bcd95d-8957-4395-9f75-b38ef48b9cae/1200x680_870x489_epalive799761.jpg"
							target="_blank">
							<img src="https://www.francebleu.fr/s3/cruiser-production/2016/08/23bcd95d-8957-4395-9f75-b38ef48b9cae/1200x680_870x489_epalive799761.jpg"
								style="border-radius: 4px;" class="img-fluid">
						</a>
						<p style="text-align: justify;">C'est ce jeudi ! Nous avons la chance d'acceuillir dans un de
							notre établissement partenaire, la présence du multiple champion du monde de Judo,
							<strong>Teddy Rinner</strong>. L'occasion de pouvoir échanger avec lui et participé à sont
							cour. <strong> Les inscription sont ouvertes !</strong>
						</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<div class="space"></div>
	<!-- SECTION COACHS -->
	<section class="les_coachs">
		<div class="container-features">
			<h2 data-aos="fade-up-right" data-aos-delay="1000" data-aos-duration="1000" data-aos-easing="ease-in-out"
				data-aos-mirror="true" data-aos-once="false" data-aos-anchor-placement="top-center"
				style="text-align: center;">Réservez votre séance, dépassez vos limites et transformez-vous grâce au
				sport !</h2>

			<div class="space"></div>
			<img src="coach.png">
		</div>
		<div class="space"></div>
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-12">
					<div class="coachs">
						<p data-aos="fade-up" data-aos-delay="700" data-aos-duration="1000"
							data-aos-easing="ease-in-out" data-aos-mirror="true" data-aos-once="false"
							data-aos-anchor-placement="top-center"><strong>Sportify</strong> propose un large choix de
							coachs adaptés à tous les niveaux et objectifs. Nos coachs sont hautement qualifiés et
							expérimentés dans différents domaines du sport et du fitness. Que vous souhaitiez perdre du
							poids, vous remettre en forme, développer votre force ou améliorer vos performances
							athlétiques, nos coachs sont là pour vous guider et vous motiver tout au long de votre
							parcours.</p>
						<p></p>
						<p data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1000"
							data-aos-easing="ease-in-out" data-aos-mirror="true" data-aos-once="false"
							data-aos-anchor-placement="top-center">Chaque coach de Sportify est
							<strong>spécialisé</strong> dans un ou plusieurs domaines tels que l'entraînement personnel,
							le fitness en groupe, le coaching sportif, la nutrition, le foot, le tennis, et bien plus
							encore. Ils sont formés pour comprendre vos besoins individuels et créer des programmes
							d'entraînement personnalisés pour vous aider à atteindre vos <strong>objectifs</strong>.
						</p>
						<p data-aos="fade-up" data-aos-delay="1300" data-aos-duration="1000"
							data-aos-easing="ease-in-out" data-aos-mirror="true" data-aos-once="false"
							data-aos-anchor-placement="top-center">Quels que soient vos objectifs sportifs, Sportify est
							la plateforme de rendez-vous parfaite pour vous aider à atteindre <strong>vos
								ambition</strong> et à vous épanouir dans <strong>votre pratique sportive</strong></p>
					</div>
				</div>

				<div class="col-lg-6 col-md-6 col-sm-12" data-aos="fade-up" data-aos-delay="1000"
					data-aos-duration="1000" data-aos-easing="ease-in-out" data-aos-mirror="true" data-aos-once="false"
					data-aos-anchor-placement="top-center">
					<img class="rosebleu" src="rosebleu.png">
					<a href="carrousel.php" style="margin-right: 50px;" class="Brdv position-absolute">Nos coachs</a>
				</div>



			</div>
		</div>

	</section>

	<!-- FOOTER -->
	<footer class="page-footer">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-3 ">
					<img style="margin: 0px; padding: 0px;" id="logo" src="logo.png" height="80" width="200" alt="logo">
					<ul class="site">
						<li>
							<a href="https://www.facebook.com/" target="_blank" rel="noreferrer"><img alt="Facebook"
									src="fb.png" style="margin: 0px; padding: 0px;" width="24" height="24"
									decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
						</li>
						<li>
							<a href="https://www.instagram.com/" target="_blank" rel="noreferrer"><img alt="instagram"
									src="insta.png" style="margin: 0px; padding: 0px;" width="24" height="24"
									decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
						</li>
						<li>
							<a href="https://www.youtube.com/" target="_blank" rel="noreferrer"><img alt="youtube"
									src="https://clipart-library.com/images/dc4LABqni.png"
									style="margin: 0px; padding: 0px;" width="24" height="20" decoding="async"
									data-nimg="1" loading="lazy" style="color:transparent"></a>
						</li>
					</ul>
				</div>

				<div class="col-lg-3" style="margin: 0px; padding: 0px; margin-left: 10px;">
					<h6 class="text-uppercase font-weight-bold">Information additionnelle</h6>
					<p style="text-align:justify;">
						Ce site utilise des cookies pour vous garantir la meilleure expérience. En poursuivant votre
						consultation, vous acceptez l’utilisation de ces cookies.
					</p>
				</div>
				<div class="col-lg-2" style="height:200px; background-color: transparent; margin-left: 30px;">
					<h6 class="text-uppercase font-weight-bold">Contact</h6>
					<p>
						37, quai de Grenelle, 75015 Paris, France <br>
						sportify@webDynamique.ece.fr <br>
						+33 01 02 03 04 05 <br>
						+33 01 03 02 05 04
					</p>
				</div>
				<div class="col-lg-3" style="margin-left: 60px;">

					<!-- GOOGLE MAP-->
					<iframe
						src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2143.576303287504!2d2.330437179343684!3d48.88009498207702!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66fa5dfd6b41f%3A0x1d20fbfc12fb96af!2sSpotify%20France%20SAS!5e0!3m2!1sfr!2sfr!4v1685467388920!5m2!1sfr!2sfr"
						width="250" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
				</div>

			</div>


			<div class="footer-copyright text-center">&copy; 2019 Copyright | Droit d'auteur: webDynamique.ece.fr</div>
		</div>
	</footer>

	<script>
		AOS.init();
	</script>

</body>

</html>