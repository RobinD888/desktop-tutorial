<?php

session_start();
$response = array();

if (isset($_SESSION['name'])) {
    $text = $_POST['text'];
    $coach_id = $_SESSION['coach_id'];

    $text_message = "<div class='msgln'><span class='chat-time'>" . date("g:i A") . "</span> <b class='username'>" . $_SESSION['name'] . "</b> " . stripslashes(htmlspecialchars($text)) . "<br></div>";
    $coach_chat_file = __DIR__ . '/chatlogs/' . $coach_id . '/log' . $coach_id . '.html';

    // Ajouter le message au fichier de chat
    file_put_contents($coach_chat_file, $text_message, FILE_APPEND | LOCK_EX);

    $response['status'] = 'success';
    $response['message'] = 'Message sent.';
    $response['chat_content'] = $text_message;
} else {
    $response['status'] = 'error';
    $response['message'] = 'User not logged in.';
}

header('Content-Type: application/json');
echo json_encode($response);
exit();
?>
