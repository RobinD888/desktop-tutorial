
<?php 
  //démarer la session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion Chatroom</title>
    <link rel="stylesheet" href="indexChatroom.css">

</head>
<body>
    <?php 
    if(isset($_POST['button_con'])){
           //si le formulaire est envoyé
           //se connecter à la base de donnée
    //Connexion à la base de données
        $con = mysqli_connect("localhost","root","","projet");
    //gérer les accents et autres caractères français
        $req= mysqli_query($con , "SET NAMES UTF8");
        $req1= mysqli_query($con , "SET NAMES UTF8");
        if(!$con){
        //si la connexion échoue , afficher :
            echo "Connexion échouée";
        }
           //extraire les infos du formulaire
        extract($_POST);
           //verifions si les champs sont vides
        if(isset($email) && isset($mdp1) && isset($coach1) && $coach1 != "" && $email != "" && $mdp1 != ""){
               //verifions si les identifiants sont justes
         $req = mysqli_query($con , "SELECT * FROM users WHERE Email = '$email' AND Password = '$mdp1'");
         $req1 = mysqli_query($con , "SELECT * FROM coach WHERE Nom = '$coach1' ");
         if(mysqli_num_rows($req) > 0 and mysqli_num_rows($req1) > 0 ){
                   //si les ids sont justes
                   //Création d'une session qui contient l'email
             $_SESSION['email'] = $email ;
             $_SESSION['coach1'] = $coach1 ;
             $_SESSION['ID'] = $_GET['coach_id'];
                   //redirection vesr la page chat
             header("location:chat.php");
                   // detruire la variable du message d'inscription
             unset($_SESSION['message']);
         }else {
                   //si non
             $error = "Email, Mots de passe ou Nom du coach incorrecte(s) !";
         }
     }else {
               //si les champs sont vides
         $error = "Veuillez remplir tous les champs !" ;
     }
 }
 ?>
 <form action=""  method="POST" class="form_connexion_inscription">
    <h2>Saisir les informations</h2>
    <?php
           //affichons le message qui dit qu'un compte a été créer
    if(isset($_SESSION['message'])){
     echo $_SESSION['message'] ;
 }
 ?>
 <p class="message_error">
    <?php 
               //affichons l'erreur
    if(isset($error)){
     echo $error ;
 }
 ?>
</p>
<label>Adresse Mail</label>
<input type="email" name="email">
<label>Mots de passe</label>
<input type="password" name="mdp1">
<label>Nom du Coach</label>
<input type="coach" name="coach1">
<input type="submit" value="Connexion" name="button_con">
</form>

</body>
</html>