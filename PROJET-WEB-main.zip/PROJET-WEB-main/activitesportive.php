		<?php
		session_start();
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title>Sportify : Activité Sportive</title> <!-- Titre du site -->

			<!-- Css et icone du site -->
			<link rel="stylesheet" type="text/css" href="activitesportive.css">
			<link rel="icon" href="onglet.png" type="image/x-icon">
			<link rel="shortcut icon" href="onglet.png" type="image/x-icon">
			<!-- Lien des différents bibliothèque -->
			<link rel="stylesheet"
			href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
			<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
			<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
			
		</head>
		<body>
			<!-- barre du haut -->
			<nav class="navbar navbar-expand-md fixed-top"> 
				<a class="navbar-brand" href="accueil.php"> 
					<img id="logo" src="logo.png" height="80" width="200" alt="logo"> <!-- affichage du logo -->
				</a>
				<button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="main-navigation"> <!-- création du menu avec les différentes fonctionnalités -->

					<!-- Barre des outils -->
					<ul class="navbar-nav">
						<li class="nav-item"><a class="nav-link" href="accueil.php"><b>Accueil</b></a></li>
						<li class="nav-item"><a class="nav-link" href="ToutParcourir.php"><b>Tout Parcourir</b></a></li>
						<li class="nav-item"><a class="nav-link" href="recherchetest.php"><b>Recherche</b></a></li>
						<li class="nav-item"><a class="nav-link" href="rendezvous.php"><b>Rendez-vous</b></a></li>

						<!-- Condition pour savoir quel compte est utilisé -->
						<li class="nav-item2"><?php
							if (isset($_SESSION["Role"])) { // Condition du compte Client
								if ($_SESSION["Role"] === "Client") {
									echo '<a class="compte" href="pageclient.php">'; 
								} else if ($_SESSION["Role"] === "Coach") { // Condition du compte Coach
									echo '<a class="compte" href="pagecoach.php">'; 
								} else if ($_SESSION["Role"] === "Admin") { // Condition du compte Admin
									echo '<a class="compte" href="pageadmin.php">';
								} else {
									echo '<a class="compte" href="compte.php">'; // Condition du compte standard
								}
							} else { // Condition du compte standard
								echo '<a class="compte" href="compte.php">';
							}
							?><strong>Mon compte</strong></a></li> <!-- Affichage du titre -->
					</ul>
					
				</div>
			</nav>

			

			<!-- Boutons de sélection d'activité -->
			<section class="activite">
				<div class="container-features" style="margin-top: 100px;"> <!-- Position vers le bas -->
					<div class="space"></div>
					<h3 style="text-align: center;"> Nos Activités Sportives </h3> <!-- Affichage du titre au centre -->
					<div class="space"></div>
					
					<div class="container features" >
						<div class="row">
							<div class="col-sm-4 text-center">
								
									<!-- Lien vers d'autre page lorsque l'on click sur le nom  et avec affichage de l'image-->
									<a href="Musculation.php" name="muscu" class="btn btn-primary" style="color: white; background-color: black;">Musculation</a>
								
								<img src="https://masantemavie.dz/wp-content/uploads/2022/05/musculation-scaled.jpg" class="img-fluid"><!--Image -->
							</div>
							<div class="col-sm-4 text-center">
								    <!-- Lien vers d'autre page lorsque l'on click sur le nom  et avec affichage de l'image-->
									<a href="Fitness.php" name="fit" class="btn btn-primary" style="color: white; background-color: black;">Fitness</a>
								
								<img src="https://www.actionclub.info/wp-content/uploads/2018/05/2.jpg" class="img-fluid"><!--Image -->
							</div>
							<div class="col-sm-4 text-center">
									<!-- Lien vers d'autre page lorsque l'on click sur le nom  et avec affichage de l'image-->
									<a href="Biking.php" name="bike" class="btn btn-primary" style="color: white; background-color: black;">Biking</a>
									
								
								<img src="https://i.f1g.fr/media/madame/orig/sites/default/files/img/2017/02/10-bonnes-raisons-de-se-mettre-au-velo-en-salle.jpg" class="img-fluid"><!--Image -->
							</div>
							<div class="col-sm-4 offset-sm-2 text-center">
									<!-- Lien vers d'autre page lorsque l'on click sur le nom  et avec affichage de l'image-->
									<a href="Cardio.php" name="cardio" class="btn btn-primary" style="color: white; background-color: black;margin-top:10px">Cardio-Training</a>
									
								
								<img src="https://olimpsport.com/media/mageplaza/blog/post/image//t/r/trening-cardio_2.jpg" class="img-fluid"><!--Image -->
							</div>
							<div class="col-sm-4 text-center">
									<!-- Lien vers d'autre page lorsque l'on click sur le nom  et avec affichage de l'image-->
									<a href="Cour_Collectifs.php" name="collectif" class="btn btn-primary" style="color: white; background-color: black;margin-top:10px">Cours Collectifs</a>
								
								
								<img src="https://www.hirtzbach-fitness.fr/wp-content/uploads/2021/11/cours-collectifs-fitness-belfort.jpg" class="img-fluid"><!--Image -->
							</div>
						</div>
					</div>
				</div>
				<div class="space"></div>
			</section>

			<!-- Creation du footer et des contenues qui sont a l'intérieur-->
			<footer class="page-footer">
				<div class="container-fluid">
					<div class="row">
						<div class="col-lg-3">
							<!-- Logo et liens vers les réseaux sociaux -->
							<img style="margin: 0px; padding: 0px;" id="logo" src="logo.png" height="80" width="200" alt="logo">
							<ul class="site">
								<li>
									<!-- Lien vers d'autre page lorsque l'on click sur l'icone  et avec affichage de l'image-->
									<a href="https://www.facebook.com/" target="_blank" rel="noreferrer"><img alt="Facebook" src="fb.png" style="margin: 0px; padding: 0px;" width="24" height="24" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
								</li>
								<li>
									<!-- Lien vers d'autre page lorsque l'on click sur l'icone  et avec affichage de l'image-->
									<a href="https://www.instagram.com/" target="_blank" rel="noreferrer"><img alt="instagram" src="insta.png" style="margin: 0px; padding: 0px;" width="24" height="24" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
								</li>
								<li>
									<!-- Lien vers d'autre page lorsque l'on click sur l'icone  et avec affichage de l'image-->
									<a href="https://www.youtube.com/" target="_blank" rel="noreferrer"><img alt="youtube" src="https://clipart-library.com/images/dc4LABqni.png" style="margin: 0px; padding: 0px;" width="24" height="20" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
								</li>
							</ul>
						</div>
						<!-- Creation du colonne 3 -->
						<div class="col-lg-3" style="margin: 0px; padding: 0px; margin-left: 10px;">
							<!-- Informations additionnelles -->
							<h6 class="text-uppercase font-weight-bold">Information additionnelle</h6>
							<p style="text-align:justify;">
								Ce site utilise des cookies pour vous garantir la meilleure expérience. En poursuivant votre consultation, vous acceptez l’utilisation de ces cookies.
							</p>
						</div>
						<div class="col-lg-2" style="height:200px; background-color: transparent; margin-left: 30px;">
							<!-- Coordonnées de contact -->
							<h6 class="text-uppercase font-weight-bold">Contact</h6>
							<p>
								37, quai de Grenelle, 75015 Paris, France <br>
								sportify@webDynamique.ece.fr <br>
								+33 01 02 03 04 05 <br>
								+33 01 03 02 05 04
							</p>
						</div>
						<div class="col-lg-3" style="margin-left: 60px;">
							<!-- Carte Google Maps -->
							<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2143.576303287504!2d2.330437179343684!3d48.88009498207702!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66fa5dfd6b41f%3A0x1d20fbfc12fb96af!2sSpotify%20France%20SAS!5e0!3m2!1sfr!2sfr!4v1685467388920!5m2!1sfr!2sfr" width="250" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
						</div>
					</div>
					<div class="footer-copyright text-center">
						&copy; 2019 Copyright | Droit d'auteur:
						webDynamique.ece.fr
					</div>
				</div>
			</footer>
		</body>
		</html>

