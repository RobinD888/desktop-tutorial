<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Rendez-vous</title>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="accueil.css">
    <link rel="stylesheet" type="text/css" href="rendezvous.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="annulerrdv.js"></script>
    <title>Sportify : Consultation Sportive</title>
    <link rel="icon" href="onglet.png" type="image/x-icon">
    <link rel="shortcut icon" href="onglet.png" type="image/x-icon">
    <script type="text/javascript">
        $(document).ready(function () {
            $('.header').height($(window).height());
        });
    </script>
    <script type="text/javascript">
        function scrollToSection(sectionId) {
            const section = document.querySelector(`#${sectionId}`);
            window.scrollTo({
                top: section.offsetTop,
                behavior: 'smooth'
            });
        }
    </script>

</head>

<body class="pt-5">
    <nav class="navbar navbar-expand-md fixed-top">
        <a class="navbar-brand" href="acceuil.html">
            <img id="logo" src="logo.png" height="80" width="200" alt="logo">
        </a>
        <button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="main-navigation">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="accueil.php"><b>Accueil</b></a></li>
                <li class="nav-item"><a class="nav-link" href="ToutParcourir.php"><b>Tout Parcourir</b></a></li>
                <li class="nav-item"><a class="nav-link" href="recherchetest.php"><b>Recherche</b></a></li>
                <li class="nav-item"><?php
                if (isset($_SESSION["Role"])) {
                    if ($_SESSION["Role"] === "Coach") {
                        echo '<a class="nav-link" href="rendezvouscoach.php">';
                    } else if ($_SESSION["Role"] === "Admin") {
                        echo '<a class="nav-link" href="accueil.php">';
                    } else {
                        echo '<a class="nav-link" href="rendezvous.php">';
                    }
                } else {
                    echo '<a class="nav-link" href="rendezvous.php">';
                }
            ?><b>Rendez-vous</b></a></li>
            <li class="nav-item2">
                <?php
                if (isset($_SESSION["Role"])) {
                    if ($_SESSION["Role"] === "Client") {
                        echo '<a class="compte" href="pageclient.php">';
                    } else if ($_SESSION["Role"] === "Coach") {
                        echo '<a class="compte" href="pagecoach.php">';
                    } else if ($_SESSION["Role"] === "Admin") {
                        echo '<a class="compte" href="pageadmin.php">';
                    } else {
                        echo '<a class="compte" href="compte.php">';
                    }
                } else {
                    echo '<a class="compte" href="compte.php">';
                }
            ?><strong>Mon compte</strong></a>
        </li>
    </ul>

</div>
</nav>
<div class="container" style="margin-top: 200px; margin-bottom: 200px;">

    <?php
        // Connexion à la base de données
        // Connexion à la base de données
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "projet";

    $conn = new mysqli($servername, $username, $password, $dbname);

        // Vérification de la connexion
    if ($conn->connect_error) {
        die("Erreur de connexion à la base de données : " . $conn->connect_error);
    }
    if (isset($_SESSION["ID"])) {
        $userID = $_SESSION['ID'];
        if ($userID !== "") {
                // Récupération de l'ID de l'utilisateur connecté (ici, utilisateur avec ID 1)
            
                // Récupération des rendez-vous futurs de l'utilisateur
            $queryFutur = "SELECT * FROM rdv WHERE ID_client = $userID AND (Date >= CURDATE() OR Date = '0000-00-00') ORDER BY Date";
            $resultFutur = $conn->query($queryFutur);

            if ($resultFutur->num_rows > 0) {
                echo "<h2>Vos rendez-vous à venir :</h2>";
                while ($row = $resultFutur->fetch_assoc()) {
                    $rdvID = $row['ID'];
                    $date = $row['Date'];
                    $jour = $row['Jour'];
                    $heure = $row['Heure'];
                    $salle = $row['Salle'];

                        // Récupération des informations sur le coach du rendez-vous
                    $coachID = $row['ID_coach'];
                    $coachQuery = "SELECT * FROM coach WHERE mail = '$coachID'";
                    $coachResult = $conn->query($coachQuery);
                    if ($coachResult->num_rows > 0) {
                        $coachRow = $coachResult->fetch_assoc();
                        $coachNom = $coachRow['Nom'];
                        $coachPrenom = $coachRow['Prenom'];
                        echo "<h3>Rendez-vous avec le coach $coachPrenom $coachNom</h3>";
                    }
                    if ($date != '0000-00-00') {
                        echo "<p>Date : $date</p>";
                    }
                    echo "<p>Jour : $jour</p>";
                    echo "<p>Heure : $heure:00</p>";
                    if (!empty($salle)) {
                        echo "<p>Salle : $salle</p>";
                    }
                    echo "<button onclick='annulerRendezVous($rdvID)'>Annuler RDV</button>";
                    echo "<hr>";
                }
            }
            else{
                echo "<h2>Vous n'avez pas de rendez-vous à venir</h2>";
            }

                // Récupération des rendez-vous passés de l'utilisateur
            $queryHistorique = "SELECT * FROM rdv WHERE ID_client = $userID AND Date < CURDATE() AND Date != '0000-00-00' ORDER BY Date DESC";
            $resultHistorique = $conn->query($queryHistorique);

            if ($resultHistorique->num_rows > 0) {
                echo "<h2>Historique de vos rendez-vous :</h2>";
                while ($row = $resultHistorique->fetch_assoc()) {
                    $rdvID = $row['ID'];
                    $date = $row['Date'];
                    $jour = $row['Jour'];
                    $heure = $row['Heure'];
                    $salle = $row['Salle'];

                        // Récupération des informations sur le coach du rendez-vous
                    $coachID = $row['ID_coach'];
                    $coachQuery = "SELECT * FROM coach WHERE mail = '$coachID'";
                    $coachResult = $conn->query($coachQuery);
                    if ($coachResult->num_rows > 0) {
                        $coachRow = $coachResult->fetch_assoc();
                        $coachNom = $coachRow['Nom'];
                        $coachPrenom = $coachRow['Prenom'];
                        echo "<h3>Rendez-vous avec le coach $coachPrenom $coachNom</h3>";
                    }

                    if (!empty($date)) {
                        echo "<p>Date : $date</p>";
                    }
                    echo "<p>Jour : $jour</p>";
                    echo "<p>Heure : $heure:00</p>";
                    if (!empty($salle)) {
                        echo "<p>Salle : $salle</p>";
                    }
                    
                    echo "<hr>";
                }
            } else {
                echo "<h2>Vous n'avez pas d'ancien rendez-vous.</h2>";
            }
            echo "<h2>Prendre un rendez-vous :</h2>";
                // Récupération des coachs disponibles
            $query = "SELECT * FROM coach";
            $result = $conn->query($query);

            if ($result->num_rows > 0) {
                echo "<form method='post' action='planning.php'>";
                echo "<label for='coach'>Coach :</label>";
                echo "<select name='coach' id='coach'>";

                while ($row = $result->fetch_assoc()) {
                    $coachID = $row['ID'];
                    $nomCoach = $row['Nom'];
                    $PrenomCoach = $row['Prenom'];
                    $EmailCoach = $row['mail'];
                    echo "<option value='$EmailCoach'>$nomCoach $PrenomCoach </option>";
                }

                echo "</select>";



                echo "<br>";

                echo "<input type='submit' value='Prendre RDV'>";
                echo "</form>";
            } else {
                echo "<p>Aucun coach disponible.</p>";
            }
        } else {
            echo "<h2>Vous n'êtes pas connecté.</h2>";
        }
    } else {
        echo "<h2>Vous n'êtes pas connecté.</h2>";
    }
    $conn->close();
    ?>


</div>
<footer class="page-footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3">
                <!-- Logo et liens vers les réseaux sociaux -->
                <img style="margin: 0px; padding: 0px;" id="logo" src="logo.png" height="80" width="200" alt="logo">
                <ul class="site">
                    <li>
                        <a href="https://www.facebook.com/" target="_blank" rel="noreferrer"><img alt="Facebook"
                            src="fb.png" style="margin: 0px; padding: 0px;" width="24" height="24"
                            decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/" target="_blank" rel="noreferrer"><img alt="instagram"
                                src="insta.png" style="margin: 0px; padding: 0px;" width="24" height="24"
                                decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
                            </li>
                            <li>
                                <a href="https://www.youtube.com/" target="_blank" rel="noreferrer"><img alt="youtube"
                                    src="https://clipart-library.com/images/dc4LABqni.png"
                                    style="margin: 0px; padding: 0px;" width="24" height="20" decoding="async"
                                    data-nimg="1" loading="lazy" style="color:transparent"></a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-lg-3" style="margin: 0px; padding: 0px; margin-left: 10px;">
                            <!-- Informations additionnelles -->
                            <h6 class="text-uppercase font-weight-bold">Information additionnelle</h6>
                            <p style="text-align:justify;">
                                Ce site utilise des cookies pour vous garantir la meilleure expérience. En poursuivant votre
                                consultation, vous acceptez l’utilisation de ces cookies.
                            </p>
                        </div>
                        <div class="col-lg-2" style="height:200px; background-color: transparent; margin-left: 30px;">
                            <!-- Coordonnées de contact -->
                            <h6 class="text-uppercase font-weight-bold">Contact</h6>
                            <p>
                                37, quai de Grenelle, 75015 Paris, France <br>
                                sportify@webDynamique.ece.fr <br>
                                +33 01 02 03 04 05 <br>
                                +33 01 03 02 05 04
                            </p>
                        </div>
                        <div class="col-lg-3" style="margin-left: 60px;">
                            <!-- Carte Google Maps -->
                            <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2143.576303287504!2d2.330437179343684!3d48.88009498207702!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66fa5dfd6b41f%3A0x1d20fbfc12fb96af!2sSpotify%20France%20SAS!5e0!3m2!1sfr!2sfr!4v1685467388920!5m2!1sfr!2sfr"
                            width="250" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                    </div>
                    <div class="footer-copyright text-center">
                        &copy; 2019 Copyright | Droit d'auteur:
                        webDynamique.ece.fr
                    </div>
                </div>
            </footer>
        </body>

        </html>