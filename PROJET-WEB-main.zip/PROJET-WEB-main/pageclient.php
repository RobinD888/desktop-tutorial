<?php
// Start the session
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="compte.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <title>Sportify : Consultation Sportive</title>
    <link rel="icon" href="onglet.png" type="image/x-icon">
    <link rel="shortcut icon" href="onglet.png" type="image/x-icon">
    <script type="text/javascript">
        $(document).ready(function () {
            $('.header').height($(window).height());
        });
    </script>
    <script type="text/javascript">
        function scrollToSection(sectionId) {
            const section = document.querySelector(`#${sectionId}`);
            window.scrollTo({
                top: section.offsetTop,
                behavior: 'smooth'
            });
        }
    </script>
</head>

<body class="pt-5">
    <nav class="navbar navbar-expand-md fixed-top">
        <a class="navbar-brand" href="accueil.php">
            <img id="logo" src="logo.png" height="80" width="200" alt="logo">
        </a>
        <button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="main-navigation">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="accueil.php"><b>Accueil</b></a></li>
                <li class="nav-item"><a class="nav-link" href="ToutParcourir.php"><b>Tout Parcourir</b></a></li>
                <li class="nav-item"><a class="nav-link" href="recherchetest.php"><b>Recherche</b></a></li>
                <li class="nav-item"><?php
                if (isset($_SESSION["Role"])) {
                    if ($_SESSION["Role"] === "Coach") {
                        echo '<a class="nav-link" href="rendezvouscoach.php">';
                    } else if ($_SESSION["Role"] === "Admin") {
                        echo '<a class="nav-link" href="accueil.php">';
                    } else {
                        echo '<a class="nav-link" href="rendezvous.php">';
                    }
                } else {
                    echo '<a class="nav-link" href="rendezvous.php">';
                }
            ?><b>Rendez-vous</b></a></li>
        </ul>
        <?php
        if (isset($_SESSION["Role"])) {
          if ($_SESSION["Role"] === "Client") {
             echo '<a class="compte" href="pageclient.php">';
         } else if ($_SESSION["Role"] === "Coach") {
             echo '<a class="compte" href="pagecoach.php">';
         } else if ($_SESSION["Role"] === "Admin") {
             echo '<a class="compte" href="pageadmin.php">';
         } else {
             echo '<a class="compte" href="compte.php">';
         }
     } else {
      echo '<a class="compte" href="compte.php">';
  }
?><strong>Mon compte</strong></a>
</div>
</nav>
<?php
    //identifier votre BDD
$database = "projet";
    //identifier votre serveur (localhost), utlisateur (root), mot de passe ("")
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);
    //On récupère les données du formulaire
if ($db_found) {
 

    } // end if
    else {
        echo "database not found";
    }
    mysqli_close($db_handle);
    ?>

    <section class="connexion" style="margin-top: 100px;">
        <div class="container-fluid">

            <div class="text-center">
                <h2><strong>Page Client</strong></h2>
                <p></p>
            </div>
            <div class="row justify-content-center my-5">
                <div class="col-lg-6" style="margin-top:150px">
                    <form method="post" action="deconnexion.php">
                        <div class="mb-4 text-right">
                            <button type="submit" class="btn">Déconnexion</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="text-center">

            </div>
        </div>
    </section>


    <footer class="page-footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3 ">
                    <img style="margin: 0px; padding: 0px;" id="logo" src="logo.png" height="80" width="200" alt="logo">
                    <ul class="site">
                        <li>
                            <a href="https://www.facebook.com/" target="_blank" rel="noreferrer"><img alt="Facebook"
                                src="fb.png" style="margin: 0px; padding: 0px;" width="24" height="24"
                                decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
                            </li>
                            <li>
                                <a href="https://www.instagram.com/" target="_blank" rel="noreferrer"><img alt="instagram"
                                    src="insta.png" style="margin: 0px; padding: 0px;" width="24" height="24"
                                    decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
                                </li>
                                <li>
                                    <a href="https://www.youtube.com/" target="_blank" rel="noreferrer"><img alt="youtube"
                                        src="https://clipart-library.com/images/dc4LABqni.png"
                                        style="margin: 0px; padding: 0px;" width="24" height="20" decoding="async"
                                        data-nimg="1" loading="lazy" style="color:transparent"></a>
                                    </li>
                                </ul>
                            </div>

                            <div class="col-lg-3" style="margin: 0px; padding: 0px; margin-left: 10px;">
                                <h6 class="text-uppercase font-weight-bold">Information additionnelle</h6>
                                <p style="text-align:justify;">
                                    Ce site utilise des cookies pour vous garantir la meilleure expérience. En poursuivant votre
                                    consultation, vous acceptez l’utilisation de ces cookies.
                                </p>
                            </div>
                            <div class="col-lg-2" style="height:200px; background-color: transparent; margin-left: 30px;">
                                <h6 class="text-uppercase font-weight-bold">Contact</h6>
                                <p>
                                    37, quai de Grenelle, 75015 Paris, France <br>
                                    sportify@webDynamique.ece.fr <br>
                                    +33 01 02 03 04 05 <br>
                                    +33 01 03 02 05 04
                                </p>
                            </div>
                            <div class="col-lg-3" style="margin-left: 60px;">
                                <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2143.576303287504!2d2.330437179343684!3d48.88009498207702!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66fa5dfd6b41f%3A0x1d20fbfc12fb96af!2sSpotify%20France%20SAS!5e0!3m2!1sfr!2sfr!4v1685467388920!5m2!1sfr!2sfr"
                                width="250" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                            </div>

                        </div>


                        <div class="footer-copyright text-center">&copy; 2019 Copyright | Droit d'auteur: webDynamique.ece.fr</div>
                    </div>
                </footer>

                <script>
                    AOS.init();
                </script>

            </body>

            </html>