<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sportify : Activité Sportive</title>

	<link rel="stylesheet" type="text/css" href="activitesportive.css">


	<link rel="icon" href="onglet.png" type="image/x-icon">
	<link rel="shortcut icon" href="onglet.png" type="image/x-icon">

	<link rel="stylesheet"
	href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<script src="sport.js" type="text/javascript"></script>


</head>
<body>
	<!-- barre du haut -->
	<nav class="navbar navbar-expand-md fixed-top"> 
		<a class="navbar-brand" href="accueil.php"> 
			<img id="logo" src="logo.png" height="80" width="200" alt="logo"> <!-- affichage du logo -->
		</a>
		<button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="main-navigation"> <!-- création du menu avec les différentes fonctionnalités -->
			<ul class="navbar-nav">
				<li class="nav-item"><a class="nav-link" href="accueil.php"><b>Accueil</b></a></li>
				<li class="nav-item"><a class="nav-link" href="ToutParcourir.php"><b>Tout Parcourir</b></a></li>
				<li class="nav-item"><a class="nav-link" href="recherchetest.php"><b>Recherche</b></a></li>
				<li class="nav-item"><?php
				if (isset($_SESSION["Role"])) {
					if ($_SESSION["Role"] === "Coach") {
						echo '<a class="nav-link" href="rendezvouscoach.php">';
					} else if ($_SESSION["Role"] === "Admin") {
						echo '<a class="nav-link" href="accueil.php">';
					} else {
						echo '<a class="nav-link" href="rendezvous.php">';
					}
				} else {
					echo '<a class="nav-link" href="rendezvous.php">';
				}
			?><b>Rendez-vous</b></a></li>
			<li class="nav-item2"><?php
			if (isset($_SESSION["Role"])) {
				if ($_SESSION["Role"] === "Client") {
					echo '<a class="compte" href="pageclient.php">';
				} else if ($_SESSION["Role"] === "Coach") {
					echo '<a class="compte" href="pagecoach.php">';
				} else if ($_SESSION["Role"] === "Admin") {
					echo '<a class="compte" href="pageadmin.php">';
				} else {
					echo '<a class="compte" href="compte.php">';
				}
			} else {
				echo '<a class="compte" href="compte.php">';
			}
		?><strong>Mon compte</strong></a></li>
	</ul>

</div>
</nav>

<!-- Boutons de sélection d'activité -->
<section class="activite">
	<div class="container-features" style="margin-top: 100px;">
		<div class="space"></div>
		<h1 style="text-align: center;"> <strong style= " text-align: center; background-image: linear-gradient(98deg, #00E1FD, #FC007A 100%);
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;">BasketBall </strong>- Le jeu passionnant sur le terrain</h1>
		<div class="space"></div>
		<div class="row"> 
			<div class="col-sm-8 mx-auto"> 
				
				<div class="d-flex justify-content-center">
					<img src="https://www.basketeurope.com/wp-content/uploads/2019/09/Evan-Fournier-4-1.jpg" height="350" width="500" style="margin: 0 auto; border-radius: 8px; ">
				</div>
				<br>
				<p style="text-align: justify;">Le basketball en compétition est un sport dynamique et captivant qui se joue avec deux équipes de cinq joueurs chacune. Il met à l'épreuve les compétences athlétiques, la stratégie et la coopération d'une équipe dans le but de marquer des paniers tout en défendant son propre panier. Que ce soit sur les terrains de rue, dans les ligues locales ou au niveau professionnel, le basketball en compétition offre une expérience unique et passionnante pour les joueurs et les fans.</p>

				<h5>Les Règles du Basketball en Compétition</h5>

				<p style="text-align: justify;">Voici quelques règles de base du basketball en compétition :</p>

				<ul style="text-align: justify;">
					<li>Le jeu se déroule sur un terrain rectangulaire avec un panier à chaque extrémité.</li>
					<li>L'objectif du jeu est de marquer des paniers en faisant passer le ballon à travers le panier de l'équipe adverse.</li>
					<li>Les joueurs peuvent dribbler le ballon tout en se déplaçant ou passer le ballon à leurs coéquipiers.</li>
					<li>Chaque panier marqué vaut deux ou trois points, selon la distance du tir.</li>
					<li>Les équipes peuvent utiliser des stratégies défensives pour empêcher les joueurs adverses de marquer.</li>
					<li>Le temps de jeu est généralement divisé en quart-temps ou en deux mi-temps, avec des pauses entre les périodes.</li>
					<li>Les fautes personnelles, les violations et les fautes techniques peuvent entraîner des lancers francs ou des possessions de balle pour l'équipe adverse.</li>
					<li>Le match se termine lorsque le temps réglementaire est écoulé et l'équipe avec le plus de points remporte la partie.</li>
				</ul>


				<h5>Les Joies du Basketball en Compétition</h5>

				<p style="text-align: justify;">Le basketball en compétition offre de nombreux avantages et joies pour les joueurs et les fans :</p>

				<ul style="text-align: justify;">
					<li>Le plaisir de jouer en équipe : le basketball est un sport collectif qui encourage la coopération, la communication et la camaraderie entre les coéquipiers.</li>
					<li>Le dépassement de soi : la compétition pousse les joueurs à se surpasser, à améliorer leurs compétences et à repousser leurs limites physiques et mentales.</li>
					<li>Les moments de grâce : les actions spectaculaires, les dunks, les passes décisives et les tirs au buzzer ajoutent une dimension excitante et mémorable au jeu.</li>
					<li>La passion des fans : le basketball en compétition attire des milliers de fans qui soutiennent leur équipe favorite, créant une atmosphère électrique dans les arènes.</li>
					<li>Les valeurs sportives : le basketball encourage le fair-play, le respect des règles, l'esprit d'équipe et l'éthique de travail, en inculquant des valeurs positives aux joueurs.</li>
				</ul>

				<p style="text-align: justify;">Que vous soyez un joueur passionné ou un fan enthousiaste, le basketball en compétition offre des moments inoubliables sur le terrain et crée des liens forts avec la communauté du basketball. Alors, prenez un ballon, enfilez vos chaussures et plongez dans l'action palpitante du basketball en compétition !</p>

			</div>
		</div>
		<?php
	// Identifiant de la base de données
		$database = "projet";

	// Connexion à la base de données
		$db_handle = mysqli_connect('localhost', 'root', '');
		$db_found = mysqli_select_db($db_handle, $database);

	// Vérification si un bouton a été cliqué

		if ($db_found) {

			$sql = "SELECT * FROM coach WHERE Specialite = 'basketball'";


			$result = mysqli_query($db_handle, $sql);


			// Affichage des résultats
			if (mysqli_num_rows($result) > 0) {
				echo '<div class="container features">';
				echo'<div class="space"></div>';
				echo '<h2>Nos Coachs de Basketball : </h2>';
				echo '<div class="space"></div>';
    echo '<div class="row">'; // Ajout de la classe row

    while ($data = mysqli_fetch_assoc($result)) {

    	$_SESSION['coach_id'] = $data['ID'];
    	$_SESSION['coach_nom'] = $data['Nom'];
    	$_SESSION['coach_prenom'] = $data['Prenom'];
    	$_SESSION['coach_specialite'] = $data['Specialite'];
    	$_SESSION['coach_salle'] = $data['Salle'];
    	$_SESSION['coach_telephone'] = $data['Telephone'];
    	$_SESSION['coach_mail'] = $data['mail'];

    	echo '<div class="col-sm-6 text-center">';
        // Conteneur flexible pour centrer la photo

    	echo '<img src="' . $data['Photo'] . '" alt="Photo du coach" height="80" width="80">';

    	echo '<h5><strong>' . $data['Prenom'] .' '. $data['Nom'] .'</strong></h5>';
    	echo '<h6><strong>Coachs, ' . $data['Specialite'] .'</strong></h6><br>';
    	echo 'Salle: ' . $data['Salle'] .'<br>';
    	echo 'Telephone: ' . $data['Telephone'] .'<br>';
    	echo 'Mail : ' . $data['mail'] .'<br>';
    	if (isset($_SESSION["ID"])) {
    		$userID = $_SESSION['ID'];
    		if ($userID !== "") {
    			echo '<a href="index_chatroom.php?coach_id=' . $data['ID'] . '"><button type="button" class="btn btn-success">Communiquer avec le coach</button></a>';
    			echo '<form method="post" action="planning.php">
    			<input type="hidden" name="coach" value="' . $data['mail'] . '">
    			<button type="submit" class="btn btn-outline-primary">Prendre un Rendez-Vous</button>
    			</form>';
    		}else {

    			echo '<a href="compte.php"><button type="button" class="btn btn-success">Communiquer avec le coach</button></a><br>';
    			echo '<form method="post" action="compte.php">
    			<button type="submit" class="btn btn-outline-primary">Prendre un Rendez-Vous</button>
    			</form>';
    			
    		}
    	} else {
    		echo '<a href="compte.php"><button type="button" class="btn btn-success">Communiquer avec le coach</button></a><br>';
    		echo '<form method="post" action="compte.php">
    		<button type="submit" class="btn btn-outline-primary">Prendre un Rendez-Vous</button>
    		</form>';
    	}
    	echo '<a href="#" onclick="showCV('.$data["ID"].')">Voir le CV</a>';
    	echo '</div>';

    }

    echo '</div>'; // Fermeture de la classe row
    echo '</div>';
} else {
	echo '<div class="container">';
	echo '<h2>Aucun résultat trouvé.</h2>';
	echo '</div>';
}


}else {
	echo '<div class="container">';
	echo '<h2>Erreur : Base de données non trouvée.</h2>';
	echo '</div>';
}


	// Fermer la connexion à la base de données
mysqli_close($db_handle);
?>


</div>
<div class="space"></div>
</section>
<!-- FOOTER -->
<footer class="page-footer">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-3">
				<!-- Logo et liens vers les réseaux sociaux -->
				<img style="margin: 0px; padding: 0px;" id="logo" src="logo.png" height="80" width="200" alt="logo">
				<ul class="site">
					<li>
						<a href="https://www.facebook.com/" target="_blank" rel="noreferrer"><img alt="Facebook" src="fb.png" style="margin: 0px; padding: 0px;" width="24" height="24" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
					</li>
					<li>
						<a href="https://www.instagram.com/" target="_blank" rel="noreferrer"><img alt="instagram" src="insta.png" style="margin: 0px; padding: 0px;" width="24" height="24" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
					</li>
					<li>
						<a href="https://www.youtube.com/" target="_blank" rel="noreferrer"><img alt="youtube" src="https://clipart-library.com/images/dc4LABqni.png" style="margin: 0px; padding: 0px;" width="24" height="20" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
					</li>
				</ul>
			</div>
			<div class="col-lg-3" style="margin: 0px; padding: 0px; margin-left: 10px;">
				<!-- Informations additionnelles -->
				<h6 class="text-uppercase font-weight-bold">Information additionnelle</h6>
				<p style="text-align:justify;">
					Ce site utilise des cookies pour vous garantir la meilleure expérience. En poursuivant votre consultation, vous acceptez l’utilisation de ces cookies.
				</p>
			</div>
			<div class="col-lg-2" style="height:200px; background-color: transparent; margin-left: 30px;">
				<!-- Coordonnées de contact -->
				<h6 class="text-uppercase font-weight-bold">Contact</h6>
				<p>
					37, quai de Grenelle, 75015 Paris, France <br>
					sportify@webDynamique.ece.fr <br>
					+33 01 02 03 04 05 <br>
					+33 01 03 02 05 04
				</p>
			</div>
			<div class="col-lg-3" style="margin-left: 60px;">
				<!-- Carte Google Maps -->
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2143.576303287504!2d2.330437179343684!3d48.88009498207702!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66fa5dfd6b41f%3A0x1d20fbfc12fb96af!2sSpotify%20France%20SAS!5e0!3m2!1sfr!2sfr!4v1685467388920!5m2!1sfr!2sfr" width="250" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
			</div>
		</div>
		<div class="footer-copyright text-center">
			&copy; 2019 Copyright | Droit d'auteur:
			webDynamique.ece.fr
		</div>
	</div>
</footer>
<!-- Fenêtre modale pour afficher le CV -->
<div class="modal" id="cvModal" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">CV du coach</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="closeCVModal()">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
			</div>
		</div>
	</div>
</div>
</body>
</html>
</body>
</html>
