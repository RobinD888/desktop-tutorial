<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Nos coachs</title>
	<link rel="icon" href="onglet.png" type="image/x-icon">
	<link rel="shortcut icon" href="onglet.png" type="image/x-icon">


	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="accueil.css">
	<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

	<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
	<style>
		.carousel {
			max-width: 600px;
			margin: 0 auto;
		}

		.carousel-caption {
			background-color: rgba(0, 0, 0, 0.7);
			padding: 10px;
			border-radius: 5px;
		}

		.carousel-caption h3,
		.carousel-caption p {
			color: #fff;
		}

		body {
			padding: 0;
			margin: 0;
			background: linear-gradient(98deg, #00E1FD, #FC007A 100%);
		}

		/* Barre de navigation */
		.navbar {
			background: linear-gradient(rgb(0, 0, 0) 30%, rgba(0, 0, 0, 0) 90%);
		}

		.nav-link,
		.navbar-brand {
			color: white;
			cursor: pointer;
		}

		.nav-link {
			margin-right: 5em !important;
			text-align: center;
		}

		.nav-link:hover {
			background-image: linear-gradient(98deg, #00E1FD, #FC007A 100%);
			-webkit-background-clip: text;
			-webkit-text-fill-color: transparent;
		}

		.navbar-collapse {
			justify-content: flex-end;
		}
		.page-footer{
			margin-top: 8px;
			background-color: black;
			color: white;
			margin-left: 7px;
			margin-right: 7px;
			border-top-left-radius: 8px;
			border-top-right-radius: 8px;
			border-bottom: none;
			padding: 40px;

		}

		.site li{

			display: inline;
			margin-right: 5px;
			list-style-type: none;

		}
		iframe {
			border-radius: 10px;
			box-shadow: 0 0 10px rgba(0,0,0,0.1);
		}
	</style>
</head>
<body>
	<nav class="navbar navbar-expand-md fixed-top">
		<a class="navbar-brand" href="acceuil.php">
			<img id="logo" src="logo.png" height="80" width="200" alt="logo">
		</a>
		<button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="main-navigation">
			<ul class="navbar-nav">
				<li class="nav-item"><a class="nav-link" href="accueil.php"><b>Accueil</b></a></li>
				<li class="nav-item"><a class="nav-link" href="ToutParcourir.php"><b>Tout Parcourir</b></a></li>
				<li class="nav-item"><a class="nav-link" href="recherchetest.php"><b>Recherche</b></a></li>
				<li class="nav-item"><?php
				if (isset($_SESSION["Role"])) {
					if ($_SESSION["Role"] === "Coach") {
						echo '<a class="nav-link" href="rendezvouscoach.php">';
					} else if ($_SESSION["Role"] === "Admin") {
						echo '<a class="nav-link" href="accueil.php">';
					} else {
						echo '<a class="nav-link" href="rendezvous.php">';
					}
				} else {
					echo '<a class="nav-link" href="rendezvous.php">';
				}
			?><b>Rendez-vous</b></a></li>
			<li class="nav-item2"><?php
			if (isset($_SESSION["Role"])) {
				if ($_SESSION["Role"] === "Client") {
					echo '<a class="compte" href="pageclient.php">';
				} else if ($_SESSION["Role"] === "Coach") {
					echo '<a class="compte" href="pagecoach.php">';
				} else if ($_SESSION["Role"] === "Admin") {
					echo '<a class="compte" href="pageadmin.php">';
				} else {
					echo '<a class="compte" href="compte.php">';
				}
			} else {
				echo '<a class="compte" href="compte.php">';
			}
		?><strong>Mon compte</strong></a></li>
	</ul>
	
</div>
</nav>
<div class="container-fluid" data-aos="fade-up"

data-aos-delay="700"
data-aos-duration="500"
data-aos-easing="ease-in-out"
data-aos-mirror="true"
data-aos-once="false"
data-aos-anchor-placement="top-center"
style="margin-bottom: 100px;">
<h2 style="text-align: center; margin-top: 140px; margin-bottom: 20px; color: black;">NOS COACHS</h2>
<div id="myCarousel" class="carousel slide" data-ride="carousel">
	<ol class="carousel-indicators">
		<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
		<li data-target="#myCarousel" data-slide-to="1"></li>
		<li data-target="#myCarousel" data-slide-to="2"></li>
		<li data-target="#myCarousel" data-slide-to="3"></li>
		<li data-target="#myCarousel" data-slide-to="4"></li>
	</ol>
	<div class="carousel-inner">
		<div class="carousel-item active">
			<img src="https://clement-nice-coaching.fr/wp-content/uploads/2022/10/P1022212-2-copie-e1665840428857.jpg" style="width: 100%; height: 350px;">
			<div class="carousel-caption">
				<h3>Clément</h3>
				
			</div>
		</div>
		<div class="carousel-item">
			<img src="https://media.istockphoto.com/id/1267469065/fr/vid%C3%A9o/verticale-du-jeune-sportif-dans-le-sportswear-restant-dans-la-gymnastique-avec-les-bras.jpg?s=640x640&k=20&c=hQfTMKSWcZz9_P-UyIR4Y_QmdRJQ-u6gwCK1mF1jxLc=" style="width: 100%; height: 350px;">
			<div class="carousel-caption">
				<h3>Tristan</h3>
				
			</div>
		</div>
		<div class="carousel-item">
			<img src="https://www.spinup.fr/wp-content/uploads/2023/04/qualites-sportif-825x538.jpg" style="width: 100%; height: 350px;">
			<div class="carousel-caption">
				
				<h3>Freddy</h3>
			</div>
		</div>
		<div class="carousel-item">
			<img src="https://resize.prod.docfr.doc-media.fr/s/1200/ext/eac4ff34/content/2022/7/23/si-je-suis-fatigue-dois-je-me-forcer-a-aller-au-sport-2d5af49966fb123b.jpeg" style="width: 100%; height: 350px;">
			<div class="carousel-caption">
				
				<h3>Natalie</h3>
			</div>
		</div>
		<div class="carousel-item">
			<img src="https://easyjobber.fr/images/trainer.jpg" style="width: 100%; height: 350px;">
			<div class="carousel-caption">
				
				<h3>Emilie</h3>
			</div>
		</div>
	</div>
	<a class="carousel-control-prev" href="#myCarousel"data-slide="prev">
		<span class="carousel-control-prev-icon" aria-hidden="true"></span>
		<span class="sr-only">Précédent</span>
	</a>
	<a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
		<span class="carousel-control-next-icon" aria-hidden="true"></span>
		<span class="sr-only">Suivant</span>
	</a>
</div>
</div>
<footer class="page-footer">
	<div class="container-fluid" >
		<div class="row">
			<div class="col-lg-3 ">
				<img style="margin: 0px; padding: 0px;" id="logo" src="logo.png" height="80" width="200" alt="logo">
				<ul class="site">
					<li>
						<a href="https://www.facebook.com/" target="_blank" rel="noreferrer"><img alt="Facebook"  src="fb.png" style="margin: 0px; padding: 0px;" width="24" height="24" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
					</li>
					<li>
						<a href="https://www.instagram.com/" target="_blank" rel="noreferrer"><img alt="instagram"  src="insta.png" style="margin: 0px; padding: 0px;" width="24" height="24" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
					</li>
					<li>
						<a href="https://www.youtube.com/" target="_blank" rel="noreferrer"><img alt="youtube"  src="https://clipart-library.com/images/dc4LABqni.png" style="margin: 0px; padding: 0px;" width="24" height="20" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
					</li>
				</ul>
			</div>

			<div class="col-lg-3" style="margin: 0px; padding: 0px; margin-left: 10px;">
				<h6 class="text-uppercase font-weight-bold">Information additionnelle</h6>
				<p style="text-align:justify;">
					Ce site utilise des cookies pour vous garantir la meilleure expérience. En poursuivant votre consultation, vous acceptez l’utilisation de ces cookies.
				</p>
			</div>
			<div class="col-lg-2" style="height:200px; background-color: transparent; margin-left: 30px;">
				<h6 class="text-uppercase font-weight-bold">Contact</h6>
				<p>
					37, quai de Grenelle, 75015 Paris, France <br>
					sportify@webDynamique.ece.fr <br>
					+33 01 02 03 04 05 <br>
					+33 01 03 02 05 04
				</p>
			</div>
			<div class="col-lg-3" style="margin-left: 60px;">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2143.576303287504!2d2.330437179343684!3d48.88009498207702!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66fa5dfd6b41f%3A0x1d20fbfc12fb96af!2sSpotify%20France%20SAS!5e0!3m2!1sfr!2sfr!4v1685467388920!5m2!1sfr!2sfr" width="250" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
			</div>

		</div>

		
		<div class="footer-copyright text-center">&copy; 2019 Copyright | Droit d'auteur: webDynamique.ece.fr</div>
	</div>
</footer>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script>
	AOS.init();
</script>
</body>
</html>

