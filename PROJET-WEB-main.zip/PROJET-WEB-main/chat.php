<?php
session_start();
$database = "projet";

// Connexion à la base de données
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);
if($_SESSION['email'])
{
   $user_email = $_SESSION['email'];
   // Requête pour récupérer les informations du coach en fonction de son mail
   $sql = "SELECT * FROM users";
         //On cherche la personne par son mail en entier grâce aux mails saisis
   if ($user_email != ""){ // Condition si le mail récupéré n'est pas vide
      $sql .= " WHERE Email LIKE '%$user_email%'"; // comparation du mail
   }
   $result = mysqli_query($db_handle, $sql); // avoir le resultat de la requete

    // Vérification si le coach existe
   if (mysqli_num_rows($result) > 0) {
        // Récupération des informations du coach
    $data = mysqli_fetch_assoc($result);

    // Déclaration des variables qui prend en compte les données du BDD
    $_SESSION['user_id'] = $data['ID'];
    $_SESSION['user_nom'] = $data['Nom'];
    $_SESSION['user_email'] = $data['Email'];
    $_SESSION['user_role'] = $data['Role'];

    // Construction du nom complet du coach
    $user_name = $data['Prenom'] . ' ' . $data['Nom'];
    $_SESSION['name'] = $user_name;
 }
}

if ($_SESSION['coach1']) { // si nous avons un coach
  $coach_nom = $_SESSION['coach1'];
  $coach_id = $_SESSION['ID'];
       // echo "DEUX ".$coach_id." DEUX";

    // Requête pour récupérer les informations du coach en fonction de son ID
  $sql = "SELECT * FROM coach";
         //On cherche le livre par son titre en entier grâce aux %
  if ($coach_nom != ""){
   $sql .= " WHERE Nom LIKE '%$coach_nom%'";
}
$result = mysqli_query($db_handle, $sql);

    // Vérification si le coach existe
if (mysqli_num_rows($result) > 0) {
   // Récupération des informations du coach
 $data = mysqli_fetch_assoc($result);

 // Déclaration des variables du coach via les données BDD
 $_SESSION['coach_id'] = $data['ID'];
 $_SESSION['coach_nom'] = $data['Nom'];
 $_SESSION['coach_prenom'] = $data['Prenom'];
 $_SESSION['coach_specialite'] = $data['Specialite'];
 $_SESSION['coach_salle'] = $data['Salle'];
 $_SESSION['coach_telephone'] = $data['Telephone'];
 $_SESSION['coach_mail'] = $data['mail'];

        // Construction du nom complet du coach
 $coach_name = $data['Prenom'] . ' ' . $data['Nom'];
 $contactmail = $data["mail"];

        // Création du répertoire de chat pour le coach s'il n'existe pas déjà
 $coach_chat_dir = __DIR__ . '/chatlogs/' . $coach_id . '/';
 if (!is_dir($coach_chat_dir)) {
   mkdir($coach_chat_dir, 0777, true);
}

        // Enregistrement du chemin du fichier de chat dans la session
$_SESSION['coach_chat_file'] = $coach_chat_dir . 'log' . $coach_id . '.html';
} else { // Affichage du résultat si coach mis
 echo '<div class="container">';
 echo '<h2>Coach introuvable.</h2>';
 echo '</div>';
}
} else { // Affichage du résultat si un coach non sélectionner
  echo '<div class="container">';
  echo '<h2>Coach non sélectionné.</h2>';
  echo '</div>';
}

if (isset($_GET['logout'])) {
   // Message de sortie simple
   $logout_message = "<div class='msgln'><span class='left-info'>L'utilisateur <b class='user-name-left'>" .
   $_SESSION['name'] . "</b> a quitté la session de chat.</span><br></div>";

   $chat_file = $_SESSION['coach_chat_file'];
   $myfile = fopen($chat_file, "a") or die("Impossible d'ouvrir le fichier!" . $chat_file);
   fwrite($myfile, $logout_message); // on écrit le message du file fichier
   fclose($myfile); // on ferme le file du fichier

   session_destroy(); // on détruit la session

   sleep(0.5); // attendre 0.5s
   header("Location: activitesportive.php"); // Rediriger l'utilisateur
}

function loginForm() // Fonction qui permet de saisis dans le  tchat le nom du client
{
   $_SESSION['name'] = "user1";
}

if (!isset($_SESSION['name'])) {
   loginForm();
}

?>

<!DOCTYPE html>
<html>

<head>
   <meta charset="utf-8" />
   <title>Exemple Chat Texto</title>
   <link rel="stylesheet" href="chat.css" /> <!-- Appel du css -->
</head>
<body>
   <div id="wrapper">
      <div id="menu">
         <!-- Message de discution entre le coach et client -->
         <p class="welcome">Vous discutez avec <b><?php echo $coach_name;?></b></p>
         <p class="logout"><a id="exit" href="#">Quitter la conversation</a></p>
      </div>
      <!-- Initialisation de l'endroit du chat  -->
      <div id="chatbox">
         <?php
         $chat_file = $_SESSION['coach_chat_file']; // saisis l'emplacement du chat
         if (file_exists($chat_file) && filesize($chat_file) > 0) {
            $contents = file_get_contents($chat_file);
            echo $contents;
         }
         ?>
      </div>
      <!--  Message et des icones mail et discord -->
      <form name="message"  action="">
         <p class="welcome"><a href="https://discord.com/invite/EAugsCzS"><img src=discord.png alt=discord width=45 height=45></a></p>
         <input name="usermsg" type="text" id="usermsg" />
         <input name="submitmsg" type="submit" id="submitmsg" value="Envoyer" />
         <p class="welcome"><?php echo "<a href=mailto:".$contactmail."><img src=mail.png alt=imageMail width=45 height=40></a>";?></p>
      </form>
   </div>
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   <script type="text/javascript">
   // jQuery Document
      $(document).ready(function() {
         $("#submitmsg").click(function() {
            location.reload();
            var clientmsg = $("#usermsg").val(); // nom du client
            $.post("post_chatroom.php", { text: clientmsg }, function(response) {
               if (response.status === 'success') { // si c'est OK
                  $("#usermsg").val("");
                  $("#chatbox").append(response.chat_content);

               // Faire défiler jusqu'au bas de la boîte de chat
                  var chatbox = document.getElementById("chatbox");
                  chatbox.scrollTop = chatbox.scrollHeight;
               } else {
                  alert("Erreur lors de l'envoi du message : " + response.message);
               }
            }, 'json');
            return false;
         });

         function loadLog() {
         var oldscrollHeight = $("#chatbox")[0].scrollHeight - 20; //Hauteur de défilement avant la requête
         $.ajax({
            url: '<?php echo $coach_chat_dir . 'log' . $coach_id . '.html';?>',
            cache: false,
            success: function(html) {
               $("#chatbox").html(html); //Insérez le log de chat dans la #chatbox div
               //Auto-scroll
               var newscrollHeight = $("#chatbox")[0].scrollHeight - 20; //Hauteur de défilement apres la requête
               if (newscrollHeight > oldscrollHeight) {
                  $("#chatbox").animate({ scrollTop: newscrollHeight }, 'normal'); //Défilement automatique
               }
            }
         });
      }
      setInterval(loadLog, 2500);
      $("#exit").click(function() {
         var exit = confirm("Voulez-vous vraiment mettre fin à la session ?");
         if (exit == true) {
            window.location = "activitesportive.php?logout=true";
         }
      });
   });
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
 $(document).ready(function() {
            // Fonction pour actualiser la page
   function actualiserPage() {
     $.ajax({
       url: window.location.href,
       method: 'GET',
       success: function(data) {
                        $('body').html(data); // Mettre à jour le contenu de la page
                     }
                  });
  }

            // Actualiser la page toutes les 5 secondes
  setInterval(actualiserPage, 10000);
});
</script>


</body>

</html>