<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Sportify: Parcourir</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="accueil.css">
	<link rel="stylesheet"
	href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<script src="menu_Parcourir.js"></script>
	<link rel="icon" href="onglet.png" type="image/x-icon">
	<link rel="shortcut icon" href="onglet.png" type="image/x-icon">
	<script type="text/javascript">
		$(document).ready(function(){
			$('.header').height($(window).height());
		});
	</script>
</head>
<body>
	<nav class="navbar navbar-expand-md fixed-top">
		<a class="navbar-brand" href="accueil.php"> 
			<img id="logo" src="logo.png" height="80" width="200" alt="logo">
		</a>
		<button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="main-navigation">
			<ul class="navbar-nav">
				<li class="nav-item"><a class="nav-link" href="accueil.php"><b>Accueil&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></a></li>
				<li class="nav-item"><a class="nav-link" href="activitesportive.php"><b>Activités Sportives&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></a></li>
				<li class="nav-item"><a class="nav-link" href="sportcompetition.php"><b>Sport Compétitif&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></a></li>
				<li class="nav-item"><a class="nav-link" href="salleomnes.php"><b>Salle Omnes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></a></li>
				<li class="nav-item2"><li class="nav-item2"><?php
				if (isset($_SESSION["Role"])) {
					if ($_SESSION["Role"] === "Client") {
						echo '<a class="compte" href="pageclient.php">';
					} else if ($_SESSION["Role"] === "Coach") {
						echo '<a class="compte" href="pagecoach.php">';
					} else if ($_SESSION["Role"] === "Admin") {
						echo '<a class="compte" href="pageadmin.php">';
					} else {
						echo '<a class="compte" href="compte.php">';
					}
				} else {
					echo '<a class="compte" href="compte.php">';
				}
			?><strong>Mon compte</strong></a></li></li>
		</ul>
	</div>
</nav>
<div class="toutpar">
	<header class="page-header header container-fluid ">
		<div class="overlay"></div>
		<div  data-aos="fade-left" data-aos-duration="1000"class="description" >
			<h1>BIENVENUE CHEZ SPORTIFY !</h1><p>
			Nous avons 3 catégories d'activitéS disponible.</p><br>
		</div>
		<canvas id="canvas"></canvas>
	</header>
</div>
<section class="sport">
	<div class="container features" style="margin-top: 100px;margin-bottom: 100px;">
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-12">
				
				<h3 class="feature-title" align="center">Activités Sportives<br></h3>
				<img src="activiteSportive.jpeg" style="border-radius: 4px;" class="img-fluid">
				<p><br>Ici, tout les membres de l'Omnes Education peuvent y participer. Voici les activités que nous proposons: Musculation, Fitness, Biking, Cardio-Training et Cours Collectifs</p>
			</div>

			<div class="col-lg-4 col-md-4 col-sm-12">
				<h3 class="feature-title" align="center">Sports de Compétition</h3>
				<img src="sportCompetition.jpeg" style="border-radius: 4px;" class="img-fluid">
				<p><br>Chez Sportify, nous avons plusieurs coachs de différents sports compétitifs qui sont disponible pour vous. Nous vous proposons dans les sport suivants: Basketball, FootBall, Rugby, Tennis, Natation et Plongeon.</p>
			</div>

			<div class="col-lg-4 col-md-4 col-sm-12">
				<h3 class="feature-title" align="center">Salle de sport Omnes</h3>
				<img src="sallesport.jpg" style="border-radius: 4px;" class="img-fluid">
				<p><br>Nous avons plusieurs services disponible notamment sur les règles de l'utilisation des machines dans la salle de sport, des horaires de la gym, des questionnaires pour les nouveaux utilisateurs, mais aussi les coordonnées des responsables de la salle de sport.</p>
			</div>
		</div>
	</div>
	<section></section>
	<footer class="page-footer">
		<div class="container-fluid" >
			<div class="row">
				<div class="col-lg-3 ">
					<img style="margin: 0px; padding: 0px;" id="logo" src="logo.png" height="80" width="200" alt="logo">
					<ul class="site">
						<li>
							<a href="https://www.facebook.com/" target="_blank" rel="noreferrer"><img alt="Facebook"  src="fb.png" style="margin: 0px; padding: 0px;" width="24" height="24" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
						</li>
						<li>
							<a href="https://www.instagram.com/" target="_blank" rel="noreferrer"><img alt="instagram"  src="insta.png" style="margin: 0px; padding: 0px;" width="24" height="24" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
						</li>
						<li>
							<a href="https://www.youtube.com/" target="_blank" rel="noreferrer"><img alt="youtube"  src="https://clipart-library.com/images/dc4LABqni.png" style="margin: 0px; padding: 0px;" width="24" height="20" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
						</li>
					</ul>
				</div>

				<div class="col-lg-3" style="margin: 0px; padding: 0px; margin-left: 10px;">
					<h6 class="text-uppercase font-weight-bold">Information additionnelle</h6>
					<p style="text-align:justify;">
						Ce site utilise des cookies pour vous garantir la meilleure expérience. En poursuivant votre consultation, vous acceptez l’utilisation de ces cookies.
					</p>
				</div>
				<div class="col-lg-2" style="height:200px; background-color: transparent; margin-left: 30px;">
					<h6 class="text-uppercase font-weight-bold">Contact</h6>
					<p>
						37, quai de Grenelle, 75015 Paris, France <br>
						sportify@webDynamique.ece.fr <br>
						+33 01 02 03 04 05 <br>
						+33 01 03 02 05 04
					</p>
				</div>
				<div class="col-lg-3" style="margin-left: 60px;">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2143.576303287504!2d2.330437179343684!3d48.88009498207702!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66fa5dfd6b41f%3A0x1d20fbfc12fb96af!2sSpotify%20France%20SAS!5e0!3m2!1sfr!2sfr!4v1685467388920!5m2!1sfr!2sfr" width="250" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
				</div>

			</div>
		</div>
		
		<div class="footer-copyright text-center">&copy; 2019 Copyright | Droit d'auteur: webDynamique.ece.fr</div>
	</div>
</footer>
</body>
</html>