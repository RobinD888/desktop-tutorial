<?php
// Start the session
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="compte.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <title>Sportify : Consultation Sportive</title>
    <link rel="icon" href="onglet.png" type="image/x-icon">
    <link rel="shortcut icon" href="onglet.png" type="image/x-icon">
    <script type="text/javascript">
        $(document).ready(function () {
            $('.header').height($(window).height());
        });
    </script>
    <script type="text/javascript">
        function scrollToSection(sectionId) {
            const section = document.querySelector(`#${sectionId}`);
            window.scrollTo({
                top: section.offsetTop,
                behavior: 'smooth'
            });
        }
    </script>
</head>

<body class="pt-5">
    <nav class="navbar navbar-expand-md fixed-top">
        <a class="navbar-brand" href="accueil.php">
            <img id="logo" src="logo.png" height="80" width="200" alt="logo">
        </a>
        <button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="main-navigation">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="accueil.php"><b>Accueil</b></a></li>
                <li class="nav-item"><a class="nav-link" href="ToutParcourir.php"><b>Tout Parcourir</b></a></li>
                <li class="nav-item"><a class="nav-link" href="recherchetest.php"><b>Recherche</b></a></li>
                <li class="nav-item"><?php
                if (isset($_SESSION["Role"])) {
                    if ($_SESSION["Role"] === "Coach") {
                        echo '<a class="nav-link" href="rendezvouscoach.php">';
                    } else if ($_SESSION["Role"] === "Admin") {
                        echo '<a class="nav-link" href="accueil.php">';
                    } else {
                        echo '<a class="nav-link" href="rendezvous.php">';
                    }
                } else {
                    echo '<a class="nav-link" href="rendezvous.php">';
                }
            ?><b>Rendez-vous</b></a></li>
            <li class="nav-item2"><?php
            if (isset($_SESSION["Role"])) {
              if ($_SESSION["Role"] === "Client") {
                 echo '<a class="compte" href="pageclient.php">';
             } else if ($_SESSION["Role"] === "Coach") {
                 echo '<a class="compte" href="pagecoach.php">';
             } else if ($_SESSION["Role"] === "Admin") {
                 echo '<a class="compte" href="pageadmin.php">';
             } else {
                 echo '<a class="compte" href="compte.php">';
             }
         } else {
          echo '<a class="compte" href="compte.php">';
      }
  ?><strong>Mon compte</strong></a></li>
</ul>

</div>
</nav>
<?php
    //identifier votre BDD
$database = "projet";
    //identifier votre serveur (localhost), utlisateur (root), mot de passe ("")
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);
    //On récupère les données du formulaire
$nom = isset($_POST["nom"]) ? $_POST["nom"] : "";
$prenom = isset($_POST["prenom"]) ? $_POST["prenom"] : "";
$email = isset($_POST["email"]) ? $_POST["email"] : "";
$password = isset($_POST["password"]) ? $_POST["password"] : "";
$adressel1 = isset($_POST["adressel1"]) ? $_POST["adressel1"] : "";
$adressel2 = isset($_POST["adressel2"]) ? $_POST["adressel2"] : "";
$codepostal = isset($_POST["codepostal"]) ? $_POST["codepostal"] : "";
$pays = isset($_POST["pays"]) ? $_POST["pays"] : "";
$ville = isset($_POST["ville"]) ? $_POST["ville"] : "";
$tel = isset($_POST["tel"]) ? $_POST["tel"] : "";
$photo = isset($_POST["photo"]) ? $_POST["photo"] : "";
$salle = isset($_POST["salle"]) ? $_POST["salle"] : "";
$cv = isset($_POST["cv"]) ? $_POST["cv"] : "";
$specialite = isset($_POST["specialite"]) ? $_POST["specialite"] : "";
$LundiAM = isset($_POST["LundiAM"]) ? $_POST["LundiAM"] : "0";
$LundiPM = isset($_POST["LundiPM"]) ? $_POST["LundiPM"] : "0";
$MardiAM = isset($_POST["MardiAM"]) ? $_POST["MardiAM"] : "0";
$MardiPM = isset($_POST["MardiPM"]) ? $_POST["MardiPM"] : "0";
$MercrediAM = isset($_POST["MercrediAM"]) ? $_POST["MercrediAM"] : "0";
$MercrediPM = isset($_POST["MercrediPM"]) ? $_POST["MercrediPM"] : "0";
$JeudiAM = isset($_POST["JeudiAM"]) ? $_POST["JeudiAM"] : "0";
$JeudiPM = isset($_POST["JeudiPM"]) ? $_POST["JeudiPM"] : "0";
$VendrediAM = isset($_POST["VendrediAM"]) ? $_POST["VendrediAM"] : "0";
$VendrediPM = isset($_POST["VendrediPM"]) ? $_POST["VendrediPM"] : "0";
$SamediAM = isset($_POST["SamediAM"]) ? $_POST["SamediAM"] : "0";
$SamediPM = isset($_POST["SamediPM"]) ? $_POST["SamediPM"] : "0";
$DimancheAM = isset($_POST["DimancheAM"]) ? $_POST["DimancheAM"] : "0";
$DimanchePM = isset($_POST["DimanchePM"]) ? $_POST["DimanchePM"] : "0";

$errmsg = "";
$validinscription = "";
if ($db_found) {
    if ($email !== "" && $password !== "" && $nom !== "" && $prenom !== "" && $adressel1 !== "" && $codepostal !== "" && $pays !== "" && $ville !== "" && $tel !== "" && $photo !== "" && $salle !== "" && $cv !== "" && $specialite !== "") {
        $sql = "SELECT * FROM `users` WHERE `Email`='$email'";
        $result = mysqli_query($db_handle, $sql);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errmsg = "Adresse email invalide";
        } else if (mysqli_num_rows($result) == 1) {
            $errmsg = "Email déjà pris";
        } else {
            $sql = "INSERT INTO `users` (`Email`,`Password`,`Nom`,`Prenom`,`AdresseL1`,`AdresseL2`,`CodePostal`,`Pays`,`Ville`,`Telephone`,`Etudiant`,`Role`) VALUES ('$email', '$password','$nom','$prenom','$adressel1','$adressel2','$codepostal','$pays','$ville','$tel','','Coach');";
            $result = mysqli_query($db_handle, $sql);
            $sql = "INSERT INTO `coach` (`Nom`,`Prenom`,`mail`,`Photo`,`Salle`,`CV`,`Specialite`,`Telephone`) VALUES ('$nom','$prenom','$email','$photo','$salle','$cv','$specialite','$tel');";
            $result = mysqli_query($db_handle, $sql);
            $sql = "INSERT INTO `disponibilite` (`ID_Coach`, `LundiAM`, `LundiPM`, `MardiAM`, `MardiPM`, `MercrediAM`, `MercrediPM`, `JeudiAM`, `JeudiPM`, `VendrediAM`, `VendrediPM`, `SamediAM`, `SamediPM`, `DimancheAM`, `DimanchePM`) VALUES ('$email', '$LundiAM', '$LundiPM', '$MardiAM', '$MardiPM', '$MercrediAM', '$MercrediPM', '$JeudiAM', '$JeudiPM', '$VendrediAM', '$VendrediPM', '$SamediAM', '$SamediPM', '$DimancheAM', '$DimanchePM')";
            $result = mysqli_query($db_handle, $sql);
            header('Location: pageadmin.php');
        }
        } // end if
        //Ajoute le compte dans la base de données
        


    } // end if
    else {
        echo "database not found";
    }
    mysqli_close($db_handle);
    ?>

    <section class="connexion" style="margin-top: 100px;">
        <div class="container-fluid">

            <div class="text-center">
                <h2><strong>Ajout d'un coach</strong></h2>
                <p></p>
            </div>
            <div class="row justify-content-center my-5">
                <div class="col-lg-7">
                    <form method="post" action="creationdecoach.php">
                        <label for="nom" class="form-label">Nom:</label>
                        <div class="input-group mb-4">
                            <span class="input-group-text">
                                <i class="bi bi-people-fill"></i>
                            </span>
                            <input type="text" name="nom" class="form-control" value="<?php echo $nom ?>" />
                        </div>
                        <label for="prenom" class="form-label">Prenom:</label>
                        <div class="input-group mb-4">
                            <span class="input-group-text">
                                <i class="bi bi-person-fill"></i>
                            </span>
                            <input type="text" name="prenom" class="form-control" value="<?php echo $prenom ?>" />
                        </div>
                        <label for="email" class="form-label">Adresse email:</label>
                        <div class="input-group mb-4">
                            <span class="input-group-text">
                                <i class="bi bi-at"></i>
                            </span>
                            <input type="text" name="email" class="form-control" placeholder="nomprenom@edu.ece.fr"
                            value="<?php echo $email ?>" />
                        </div>
                        <label for="password" class="form-label">Mot de passe:</label>
                        <div class="mb-4 input-group">
                            <span class="input-group-text">
                                <i class="bi bi-lock-fill"></i>
                            </span>
                            <input type="password" name="password" class="form-control"
                            value="<?php echo $password ?>" />
                        </div>
                        <label for="adressel1" class="form-label">Adresse ligne 1:</label>
                        <div class="input-group mb-4">
                            <span class="input-group-text">
                                <i class="bi bi-house-fill"></i>
                            </span>
                            <input type="text" name="adressel1" class="form-control" value="<?php echo $adressel1 ?>" />
                        </div>
                        <label for="adressel2" class="form-label">Adresse ligne 2:</label>
                        <div class="input-group mb-4">
                            <span class="input-group-text">
                                <i class="bi bi-door-open"></i>
                            </span>
                            <input type="text" name="adressel2" class="form-control" value="<?php echo $adressel2 ?>" />
                        </div>
                        <label for="codepostal" class="form-label">Code postal:</label>
                        <div class="input-group mb-4">
                            <span class="input-group-text">
                                <i class="bi bi-mailbox"></i>
                            </span>
                            <input type="text" name="codepostal" class="form-control"
                            value="<?php echo $codepostal ?>" />
                        </div>
                        <label for="pays" class="form-label">Pays:</label>
                        <div class="input-group mb-4">
                            <span class="input-group-text">
                                <i class="bi bi-flag-fill"></i>
                            </span>
                            <input type="text" name="pays" class="form-control" value="<?php echo $pays ?>" />
                        </div>
                        <label for="ville" class="form-label">Ville:</label>
                        <div class="input-group mb-4">
                            <span class="input-group-text">
                                <i class="bi bi-buildings"></i>
                            </span>
                            <input type="text" name="ville" class="form-control" value="<?php echo $ville ?>" />
                        </div>
                        <label for="tel" class="form-label">Telephone:</label>
                        <div class="input-group mb-4">
                            <span class="input-group-text">
                                <i class="bi bi-telephone"></i>
                            </span>
                            <input type="text" name="tel" class="form-control" value="<?php echo $tel ?>" />
                        </div>
                        
                        <label for="photo" class="form-label">Photo:</label>
                        <div class="input-group mb-4">
                            <span class="input-group-text">
                                <i class="bi bi-image"></i>
                            </span>
                            <input type="text" name="photo" class="form-control" value="<?php echo $photo ?>" />
                        </div>
                        <label for="salle" class="form-label">Salle:</label>
                        <div class="input-group mb-4">
                            <span class="input-group-text">
                                <i class="bi bi-door-closed"></i>
                            </span>
                            <input type="text" name="salle" class="form-control" value="<?php echo $salle ?>" />
                        </div>
                        <label for="specialite" class="form-label">Spécialité:</label>
                        <div class="input-group mb-4">
                            <span class="input-group-text">
                                <i class="bi bi-list-check"></i>
                            </span>
                            <input type="text" name="specialite" class="form-control"
                            value="<?php echo $specialite ?>" />
                        </div>
                        <label for="cv" class="form-label">CV:</label>
                        <div class="input-group mb-4">
                            <span class="input-group-text">
                                <i class="bi bi-file-text"></i>
                            </span>
                            <input type="text" name="cv" class="form-control" value="<?php echo $cv ?>" />
                        </div>
                        <label class="form-label">Disponibilité:</label>
                        <div class="mb-4 text-center">
                            <div class="custom-control custom-checkbox custom-control-inline">
                                <input class="custom-control-input" type="checkbox" id="LundiAM" name="LundiAM"
                                value="1">
                                <label class="custom-control-label" for="LundiAM">LundiAM</label>
                            </div>
                            <div class="custom-control custom-checkbox custom-control-inline">
                                <input class="custom-control-input" type="checkbox" id="MardiAM" name="MardiAM"
                                value="1">
                                <label class="custom-control-label" for="MardiAM">MardiAM</label>
                            </div>
                            <div class="custom-control custom-checkbox custom-control-inline">
                                <input class="custom-control-input" type="checkbox" id="MercrediAM" name="MercrediAM"
                                value="1">
                                <label class="custom-control-label" for="MercrediAM">MercrediAM</label>
                            </div>
                            <div class="custom-control custom-checkbox custom-control-inline">
                                <input class="custom-control-input" type="checkbox" id="JeudiAM" name="JeudiAM"
                                value="1">
                                <label class="custom-control-label" for="JeudiAM">JeudiAM</label>
                            </div>
                            <div class="custom-control custom-checkbox custom-control-inline">
                                <input class="custom-control-input" type="checkbox" id="VendrediAM" name="VendrediAM"
                                value="1">
                                <label class="custom-control-label" for="VendrediAM">VendrediAM</label>
                            </div>
                            <div class="custom-control custom-checkbox custom-control-inline">
                                <input class="custom-control-input" type="checkbox" id="SamediAM" name="SamediAM"
                                value="1">
                                <label class="custom-control-label" for="SamediAM">SamediAM</label>
                            </div>
                            <div class="custom-control custom-checkbox custom-control-inline">
                                <input class="custom-control-input" type="checkbox" id="DimancheAM" name="DimancheAM"
                                value="1">
                                <label class="custom-control-label" for="DimancheAM">DimancheAM</label>
                            </div>

                            <div class="custom-control custom-checkbox custom-control-inline">
                                <input class="custom-control-input" type="checkbox" id="LundiPM" name="LundiPM"
                                value="1">
                                <label class="custom-control-label" for="LundiPM">LundiPM</label>
                            </div>
                            <div class="custom-control custom-checkbox custom-control-inline">
                                <input class="custom-control-input" type="checkbox" id="MardiPM" name="MardiPM"
                                value="1">
                                <label class="custom-control-label" for="MardiPM">MardiPM</label>
                            </div>
                            <div class="custom-control custom-checkbox custom-control-inline">
                                <input class="custom-control-input" type="checkbox" id="MercrediPM" name="MercrediPM"
                                value="1">
                                <label class="custom-control-label" for="MercrediPM">MercrediPM</label>
                            </div>
                            <div class="custom-control custom-checkbox custom-control-inline">
                                <input class="custom-control-input" type="checkbox" id="JeudiPM" name="JeudiPM"
                                value="1">
                                <label class="custom-control-label" for="JeudiPM">JeudiPM</label>
                            </div>
                            <div class="custom-control custom-checkbox custom-control-inline">
                                <input class="custom-control-input" type="checkbox" id="VendrediPM" name="VendrediPM"
                                value="1">
                                <label class="custom-control-label" for="VendrediPM">VendrediPM</label>
                            </div>
                            <div class="custom-control custom-checkbox custom-control-inline">
                                <input class="custom-control-input" type="checkbox" id="SamediPM" name="SamediPM"
                                value="1">
                                <label class="custom-control-label" for="SamediPM">SamediPM</label>
                            </div>
                            <div class="custom-control custom-checkbox custom-control-inline">
                                <input class="custom-control-input" type="checkbox" id="DimanchePM" name="DimanchePM"
                                value="1">
                                <label class="custom-control-label" for="DimanchePM">DimanchePM</label>
                            </div>
                        </div>
                        <div class="mb-4 text-center">
                            <?php echo "<br>$errmsg<br>"; ?>
                        </div>
                        <div class="mb-4 text-center">
                            <button type="submit" class="btn">Ajouter</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="text-center">

            </div>
        </div>
    </section>


    <footer class="page-footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3 ">
                    <img style="margin: 0px; padding: 0px;" id="logo" src="logo.png" height="80" width="200" alt="logo">
                    <ul class="site">
                        <li>
                            <a href="https://www.facebook.com/" target="_blank" rel="noreferrer"><img alt="Facebook"
                                src="fb.png" style="margin: 0px; padding: 0px;" width="24" height="24"
                                decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
                            </li>
                            <li>
                                <a href="https://www.instagram.com/" target="_blank" rel="noreferrer"><img alt="instagram"
                                    src="insta.png" style="margin: 0px; padding: 0px;" width="24" height="24"
                                    decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
                                </li>
                                <li>
                                    <a href="https://www.youtube.com/" target="_blank" rel="noreferrer"><img alt="youtube"
                                        src="https://clipart-library.com/images/dc4LABqni.png"
                                        style="margin: 0px; padding: 0px;" width="24" height="20" decoding="async"
                                        data-nimg="1" loading="lazy" style="color:transparent"></a>
                                    </li>
                                </ul>
                            </div>

                            <div class="col-lg-3" style="margin: 0px; padding: 0px; margin-left: 10px;">
                                <h6 class="text-uppercase font-weight-bold">Information additionnelle</h6>
                                <p style="text-align:justify;">
                                    Ce site utilise des cookies pour vous garantir la meilleure expérience. En poursuivant votre
                                    consultation, vous acceptez l’utilisation de ces cookies.
                                </p>
                            </div>
                            <div class="col-lg-2" style="height:200px; background-color: transparent; margin-left: 30px;">
                                <h6 class="text-uppercase font-weight-bold">Contact</h6>
                                <p>
                                    37, quai de Grenelle, 75015 Paris, France <br>
                                    sportify@webDynamique.ece.fr <br>
                                    +33 01 02 03 04 05 <br>
                                    +33 01 03 02 05 04
                                </p>
                            </div>
                            <div class="col-lg-3" style="margin-left: 60px;">
                                <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2143.576303287504!2d2.330437179343684!3d48.88009498207702!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66fa5dfd6b41f%3A0x1d20fbfc12fb96af!2sSpotify%20France%20SAS!5e0!3m2!1sfr!2sfr!4v1685467388920!5m2!1sfr!2sfr"
                                width="250" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                            </div>

                        </div>


                        <div class="footer-copyright text-center">&copy; 2019 Copyright | Droit d'auteur: webDynamique.ece.fr</div>
                    </div>
                </footer>

                <script>
                    AOS.init();
                </script>

            </body>

            </html>