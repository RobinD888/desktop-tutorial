<?php
// Start the session
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz"
    crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="compte.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <title>Sportify : Consultation Sportive</title>
    <link rel="icon" href="onglet.png" type="image/x-icon">
    <link rel="shortcut icon" href="onglet.png" type="image/x-icon">
    <script type="text/javascript">
        $(document).ready(function () {
            $('.header').height($(window).height());
        });
    </script>
    <script type="text/javascript">
        function scrollToSection(sectionId) {
            const section = document.querySelector(`#${sectionId}`);
            window.scrollTo({
                top: section.offsetTop,
                behavior: 'smooth'
            });
        }
    </script>
</head>

<body class="pt-5">
    <nav class="navbar navbar-expand-md fixed-top">
        <a class="navbar-brand" href="accueil.php">
            <img id="logo" src="logo.png" height="80" width="200" alt="logo">
        </a>
        <button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="main-navigation">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="accueil.php"><b>Accueil</b></a></li>
                <li class="nav-item"><a class="nav-link" href="ToutParcourir.php"><b>Tout Parcourir</b></a></li>
                <li class="nav-item"><a class="nav-link" href="recherchetest.php"><b>Recherche</b></a></li>
                <li class="nav-item"><?php
                if (isset($_SESSION["Role"])) {
                    if ($_SESSION["Role"] === "Coach") {
                        echo '<a class="nav-link" href="rendezvouscoach.php">';
                    } else if ($_SESSION["Role"] === "Admin") {
                        echo '<a class="nav-link" href="accueil.php">';
                    } else {
                        echo '<a class="nav-link" href="rendezvous.php">';
                    }
                } else {
                    echo '<a class="nav-link" href="rendezvous.php">';
                }
            ?><b>Rendez-vous</b></a></li>
            <li class="nav-item2">
                <?php
                if (isset($_SESSION["Role"])) {
                    if ($_SESSION["Role"] === "Client") {
                        echo '<a class="compte" href="pageclient.php">';
                    } else if ($_SESSION["Role"] === "Coach") {
                        echo '<a class="compte" href="pagecoach.php">';
                    } else if ($_SESSION["Role"] === "Admin") {
                        echo '<a class="compte" href="pageadmin.php">';
                    } else {
                        echo '<a class="compte" href="compte.php">';
                    }
                } else {
                    echo '<a class="compte" href="compte.php">';
                }
            ?><strong>Mon compte</strong></a>
        </li>
    </ul>

</div>
</nav>
<?php
    ////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////PHP/////////////////////////////////////////
    //identifier votre BDD//////////////////////////////////////////////////////////////
$database = "projet";
    //identifier votre serveur (localhost), utlisateur (root), mot de passe ("")
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);
    //On fait un form method post quand on veut prendre rdv avec un coach
$IDCoachRDV = isset($_POST["coach"]) ? $_POST["coach"]: "" ;
    //test
$LundiAM = "";
$LundiPM = "";
$MardiAM = "";
$MardiPM = "";
$MercrediAM = "";
$MercrediPM = "";
$JeudiAM = "";
$JeudiPM = "";
$VendrediAM = "";
$VendrediPM = "";
$SamediAM = "";
$SamediPM = "";
$DimancheAM = "";
$DimanchePM = "";
    //On récupère les donnees de la prise de rdv
$Jour = isset($_POST["Jour"]) ? $_POST["Jour"] : "";
$Heure = isset($_POST["Heure"]) ? $_POST["Heure"] : "";
$SalleRDV = "";
    //On récupère les données du formulaire
if (isset($_SESSION["ID"])) {
    if ($_SESSION["ID"] !== "") {
        if ($db_found) {
            if ($Jour != "" && $Heure != "") {
                $sql = "SELECT * FROM `coach` WHERE `mail` = '$IDCoachRDV'";
                $result = mysqli_query($db_handle, $sql);
                while ($data = mysqli_fetch_assoc($result)) {
                    $SalleRDV = $data["Salle"];
                    $NomCoach = $data["Nom"];
                    $PrenomCoach = $data["Prenom"];
                }
                $sql = "INSERT INTO `rdv`( `ID_coach`, `ID_client`, `Jour`, `Heure`, `Information`, `Salle`) VALUES ('$IDCoachRDV','" . $_SESSION["ID"] . "','$Jour','$Heure',' ','$SalleRDV')";
                    $result = mysqli_query($db_handle, $sql);
                    //$message ="Vous avez un nouveau rendez-vous avec  ". $_SESSION["Prenom"] ." ". $_SESSION["Nom"] ." le $Jour à $Heure heure" ;
                    //mail("$IDCoachRDV","Nouveau rendez-vous",$message,'');
                    //$message ="Votre rendez avec $PrenomCoach $NomCoach le $Jour à $Heure heure est confirmé" ;
                    //mail($_SESSION["Email"],"Nouveau rendez-vous",$message,'');
                    /////////////////////////////////////////////////////////////////

                    header("Refresh: 0; url= http://localhost/PROJET-WEB/paiement.php");
                    /////////////////////////////////////////////////////////////////
                }
                $userID = $_SESSION["ID"];
                $rdvexistant = array();
                $sql = "SELECT * FROM `rdv` WHERE `ID_client` = '$userID'";
                $result = mysqli_query($db_handle, $sql);
                while ($data = mysqli_fetch_assoc($result)) {
                    $rdvexistant[] = $data["Jour"] . $data["Heure"];
                }
                $sql = "SELECT * FROM `rdv` WHERE `ID_coach` = '$IDCoachRDV'";
                $result = mysqli_query($db_handle, $sql);
                while ($data = mysqli_fetch_assoc($result)) {
                    $rdvexistant[] = $data["Jour"] . $data["Heure"];
                }
                //////////////////////////////////////////////////////Aussi récupérer les disponibilités du coach
                $sql = "SELECT * FROM `disponibilite` WHERE `ID_coach` = '$IDCoachRDV'";
                $result = mysqli_query($db_handle, $sql);
                while ($data = mysqli_fetch_assoc($result)) {
                    $LundiAM = $data["LundiAM"];
                    $LundiPM = $data["LundiPM"];
                    $MardiAM = $data["MardiAM"];
                    $MardiPM = $data["MardiPM"];
                    $MercrediAM = $data["MercrediAM"];
                    $MercrediPM = $data["MercrediPM"];
                    $JeudiAM = $data["JeudiAM"];
                    $JeudiPM = $data["JeudiPM"];
                    $VendrediAM = $data["VendrediAM"];
                    $VendrediPM = $data["VendrediPM"];
                    $SamediAM = $data["SamediAM"];
                    $SamediPM = $data["SamediPM"];
                    $DimancheAM = $data["DimancheAM"];
                    $DimanchePM = $data["DimanchePM"];
                }
            } // end if
            else {
                echo "database not found";
            }
        }
    }


    mysqli_close($db_handle);
    ////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////PHP/////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////
    ?>

    <section class="connexion" style="margin-top: 100px;">
        <div class="container-fluid">

            <div class="text-center">
                <h2><strong>Prendre un rendez-vous avec <?php echo $IDCoachRDV ?></strong></h2>
                <p></p>
            </div>

            <div class="row justify-content-center my-5">
                <div class="col-lg-8">
                    <table class="table table-striped-columns text-center ">
                        <thead>
                            <tr>
                                <th scope="col">Lundi</th>
                                <th scope="col">Mardi</th>
                                <th scope="col">Mercredi</th>
                                <th scope="col">Jeudi</th>
                                <th scope="col">Vendredi</th>
                                <th scope="col">Samedi</th>
                                <th scope="col">Dimanche</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Lundi">
                                        <input type="hidden" name="Heure" value="9">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Lundi9", $rdvexistant)) || ($LundiAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>9:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Mardi">
                                        <input type="hidden" name="Heure" value="9">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Mardi9", $rdvexistant)) || ($MardiAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>9:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Mercredi">
                                        <input type="hidden" name="Heure" value="9">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Mercredi9", $rdvexistant)) || ($MercrediAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>9:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Jeudi">
                                        <input type="hidden" name="Heure" value="9">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Jeudi9", $rdvexistant)) || ($JeudiAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>9:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Vendredi">
                                        <input type="hidden" name="Heure" value="9">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Vendredi9", $rdvexistant)) || ($VendrediAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>9:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Samedi">
                                        <input type="hidden" name="Heure" value="9">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Samedi9", $rdvexistant)) || ($SamediAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>9:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Dimanche">
                                        <input type="hidden" name="Heure" value="9">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Dimanche9", $rdvexistant)) || ($DimancheAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>9:00</button>
                                    </form>
                                </td>
                            </tr>
                            <tr>

                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Lundi">
                                        <input type="hidden" name="Heure" value="10">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Lundi10", $rdvexistant)) || ($LundiAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>10:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Mardi">
                                        <input type="hidden" name="Heure" value="10">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Mardi10", $rdvexistant)) || ($MardiAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>10:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Mercredi">
                                        <input type="hidden" name="Heure" value="10">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Mercredi10", $rdvexistant)) || ($MercrediAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>10:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Jeudi">
                                        <input type="hidden" name="Heure" value="10">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Jeudi10", $rdvexistant)) || ($JeudiAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>10:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Vendredi">
                                        <input type="hidden" name="Heure" value="10">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Vendredi10", $rdvexistant)) || ($VendrediAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>10:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Samedi">
                                        <input type="hidden" name="Heure" value="10">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Samedi10", $rdvexistant)) || ($SamediAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>10:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Dimanche">
                                        <input type="hidden" name="Heure" value="10">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Dimanche10", $rdvexistant)) || ($DimancheAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>10:00</button>
                                    </form>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Lundi">
                                        <input type="hidden" name="Heure" value="11">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Lundi11", $rdvexistant)) || ($LundiAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>11:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Mardi">
                                        <input type="hidden" name="Heure" value="11">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Mardi11", $rdvexistant)) || ($MardiAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>11:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Mercredi">
                                        <input type="hidden" name="Heure" value="11">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Mercredi11", $rdvexistant)) || ($MercrediAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>11:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Jeudi">
                                        <input type="hidden" name="Heure" value="11">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Jeudi11", $rdvexistant)) || ($JeudiAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>11:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Vendredi">
                                        <input type="hidden" name="Heure" value="11">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Vendredi11", $rdvexistant)) || ($VendrediAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>11:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Samedi">
                                        <input type="hidden" name="Heure" value="11">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Samedi11", $rdvexistant)) || ($SamediAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>11:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Dimanche">
                                        <input type="hidden" name="Heure" value="11">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Dimanche11", $rdvexistant)) || ($DimancheAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>11:00</button>
                                    </form>
                                </td>

                            </tr>
                            <tr>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Lundi">
                                        <input type="hidden" name="Heure" value="12">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Lundi12", $rdvexistant)) || ($LundiAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>12:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Mardi">
                                        <input type="hidden" name="Heure" value="12">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Mardi12", $rdvexistant)) || ($MardiAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>12:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Mercredi">
                                        <input type="hidden" name="Heure" value="12">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Mercredi12", $rdvexistant)) || ($MercrediAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>12:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Jeudi">
                                        <input type="hidden" name="Heure" value="12">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Jeudi12", $rdvexistant)) || ($JeudiAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>12:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Vendredi">
                                        <input type="hidden" name="Heure" value="12">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Vendredi12", $rdvexistant)) || ($VendrediAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>12:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Samedi">
                                        <input type="hidden" name="Heure" value="12">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Samedi12", $rdvexistant)) || ($SamediAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>12:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Dimanche">
                                        <input type="hidden" name="Heure" value="12">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Dimanche12", $rdvexistant)) || ($DimancheAM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>12:00</button>
                                    </form>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Lundi">
                                        <input type="hidden" name="Heure" value="14">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Lundi14", $rdvexistant)) || ($LundiPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>14:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Mardi">
                                        <input type="hidden" name="Heure" value="14">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Mardi14", $rdvexistant)) || ($MardiPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>14:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Mercredi">
                                        <input type="hidden" name="Heure" value="14">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Mercredi14", $rdvexistant)) || ($MercrediPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>14:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Jeudi">
                                        <input type="hidden" name="Heure" value="14">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Jeudi14", $rdvexistant)) || ($JeudiPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>14:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Vendredi">
                                        <input type="hidden" name="Heure" value="14">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Vendredi14", $rdvexistant)) || ($VendrediPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>14:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Samedi">
                                        <input type="hidden" name="Heure" value="14">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Samedi14", $rdvexistant)) || ($SamediPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>14:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Dimanche">
                                        <input type="hidden" name="Heure" value="14">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Dimanche14", $rdvexistant)) || ($DimanchePM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>14:00</button>
                                    </form>
                                </td>

                            </tr>
                            <tr>

                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Lundi">
                                        <input type="hidden" name="Heure" value="15">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Lundi15", $rdvexistant)) || ($LundiPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>15:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Mardi">
                                        <input type="hidden" name="Heure" value="15">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Mardi15", $rdvexistant)) || ($MardiPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>15:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Mercredi">
                                        <input type="hidden" name="Heure" value="15">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Mercredi15", $rdvexistant)) || ($MercrediPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>15:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Jeudi">
                                        <input type="hidden" name="Heure" value="15">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Jeudi15", $rdvexistant)) || ($JeudiPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>15:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Vendredi">
                                        <input type="hidden" name="Heure" value="15">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Vendredi15", $rdvexistant)) || ($VendrediPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>15:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Samedi">
                                        <input type="hidden" name="Heure" value="15">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Samedi15", $rdvexistant)) || ($SamediPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>15:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Dimanche">
                                        <input type="hidden" name="Heure" value="15">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Dimanche15", $rdvexistant)) || ($DimanchePM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>15:00</button>
                                    </form>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Lundi">
                                        <input type="hidden" name="Heure" value="16">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Lundi16", $rdvexistant)) || ($LundiPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>16:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Mardi">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">   
                                        <input type="hidden" name="Heure" value="16">
                                        <button type="submit" class="btn btn-outline-primary"
                                        <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Mardi16", $rdvexistant)) || ($MardiPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>16:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Mercredi">
                                        <input type="hidden" name="Heure" value="16">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary"
                                        <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Mercredi16", $rdvexistant)) || ($MercrediPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>16:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Jeudi">
                                        <input type="hidden" name="Heure" value="16">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary"
                                        <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Jeudi16", $rdvexistant)) || ($JeudiPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>16:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Vendredi">
                                        <input type="hidden" name="Heure" value="16">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary"
                                        <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Vendredi16", $rdvexistant)) || ($VendrediPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>16:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Samedi">
                                        <input type="hidden" name="Heure" value="16">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary"
                                        <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Samedi16", $rdvexistant)) || ($SamediPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>16:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Dimanche">
                                        <input type="hidden" name="Heure" value="16">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary"
                                        <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Dimanche16", $rdvexistant)) || ($DimanchePM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>16:00</button>
                                    </form>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden" name="Jour" value="Lundi">
                                        <input type="hidden" name="Heure" value="17">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary" <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Lundi17", $rdvexistant)) || ($LundiPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>17:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden"name="Jour" value="Mardi">
                                        <input type="hidden" name="Heure" value="17">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary"
                                        <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Mardi17", $rdvexistant)) || ($MardiPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>17:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden"name="Jour" value="Mercredi">
                                        <input type="hidden" name="Heure" value="17">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary"
                                        <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Mercredi17", $rdvexistant)) || ($MercrediPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>17:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden"name="Jour" value="Jeudi">
                                        <input type="hidden" name="Heure" value="17">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary"
                                        <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Jeudi17", $rdvexistant)) || ($JeudiPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>17:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden"name="Jour" value="Vendredi">
                                        <input type="hidden" name="Heure" value="17">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary"
                                        <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Vendredi17", $rdvexistant)) || ($VendrediPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>17:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden"name="Jour" value="Samedi">
                                        <input type="hidden" name="Heure" value="17">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary"
                                        <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Samedi17", $rdvexistant)) || ($SamediPM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>17:00</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="planning.php">
                                        <input type="hidden"name="Jour" value="Dimanche">
                                        <input type="hidden" name="Heure" value="17">
                                        <input type="hidden" name="coach" value="<?php echo $IDCoachRDV ?>">
                                        <button type="submit" class="btn btn-outline-primary"
                                        <?php if (isset($_SESSION["ID"])) {
                                            if ($_SESSION["ID"] !== "") {
                                                if ((in_array("Dimanche17", $rdvexistant)) || ($DimanchePM == 0)) {
                                                    echo 'disabled';
                                                }
                                            }
                                        } ?>>17:00</button>
                                    </form>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
        <div class="text-center">

        </div>
    </div>
</section>


<footer class="page-footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 ">
                <img style="margin: 0px; padding: 0px;" id="logo" src="logo.png" height="80" width="200" alt="logo">
                <ul class="site">
                    <li>
                        <a href="https://www.facebook.com/" target="_blank" rel="noreferrer"><img alt="Facebook"
                            src="fb.png" style="margin: 0px; padding: 0px;" width="24" height="24"
                            decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/" target="_blank" rel="noreferrer"><img alt="instagram"
                                src="insta.png" style="margin: 0px; padding: 0px;" width="24" height="24"
                                decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
                            </li>
                            <li>
                                <a href="https://www.youtube.com/" target="_blank" rel="noreferrer"><img alt="youtube"
                                    src="https://clipart-library.com/images/dc4LABqni.png"
                                    style="margin: 0px; padding: 0px;" width="24" height="20" decoding="async"
                                    data-nimg="1" loading="lazy" style="color:transparent"></a>
                                </li>
                            </ul>
                        </div>

                        <div class="col-lg-3" style="margin: 0px; padding: 0px; margin-left: 10px;">
                            <h6 class="text-uppercase font-weight-bold">Information additionnelle</h6>
                            <p style="text-align:justify;">
                                Ce site utilise des cookies pour vous garantir la meilleure expérience. En poursuivant votre
                                consultation, vous acceptez l’utilisation de ces cookies.
                            </p>
                        </div>
                        <div class="col-lg-2" style="height:200px; background-color: transparent; margin-left: 30px;">
                            <h6 class="text-uppercase font-weight-bold">Contact</h6>
                            <p>
                                37, quai de Grenelle, 75015 Paris, France <br>
                                sportify@webDynamique.ece.fr <br>
                                +33 01 02 03 04 05 <br>
                                +33 01 03 02 05 04
                            </p>
                        </div>
                        <div class="col-lg-3" style="margin-left: 60px;">
                            <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2143.576303287504!2d2.330437179343684!3d48.88009498207702!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66fa5dfd6b41f%3A0x1d20fbfc12fb96af!2sSpotify%20France%20SAS!5e0!3m2!1sfr!2sfr!4v1685467388920!5m2!1sfr!2sfr"
                            width="250" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        </div>

                    </div>


                    <div class="footer-copyright text-center">&copy; 2019 Copyright | Droit d'auteur: webDynamique.ece.fr</div>
                </div>
            </footer>

            <script>
                AOS.init();
            </script>

        </body>

        </html>