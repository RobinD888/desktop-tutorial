<?php
session_start();
$database = "projet";

// Connexion à la base de données
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

if ($_SESSION['Nom']) {
    $coach_nom = $_SESSION['Nom'];
    //$coach_id = $_SESSION['ID'];
       // echo "DEUX ".$coach_id." DEUX";

    // Requête pour récupérer les informations du coach en fonction de son ID
    $sql = "SELECT * FROM coach";
         //On cherche le livre par son titre en entier grâce aux %
    if ($coach_nom != ""){
        $sql .= " WHERE Nom LIKE '%$coach_nom%'";
    }
    $result = mysqli_query($db_handle, $sql);

    // Vérification si le coach existe
    if (mysqli_num_rows($result) > 0) {
        // Récupération des informations du coach
        $data = mysqli_fetch_assoc($result);
        $_SESSION['coach_id'] = $data['ID'];
        $_SESSION['coach_nom'] = $data['Nom'];
        $_SESSION['coach_prenom'] = $data['Prenom'];
        $_SESSION['coach_specialite'] = $data['Specialite'];
        $_SESSION['coach_salle'] = $data['Salle'];
        $_SESSION['coach_telephone'] = $data['Telephone'];
        $_SESSION['coach_mail'] = $data['mail'];
        $coach_id = $data['ID'];
        // Construction du nom complet du coach
        $coach_name = $data['Prenom'] . ' ' . $data['Nom'];
        $_SESSION['name'] = $coach_name;

        $contactmail = $data["mail"];

        // Création du répertoire de chat pour le coach s'il n'existe pas déjà
        $coach_chat_dir = __DIR__ . '/chatlogs/' . $coach_id . '/';
        if (!is_dir($coach_chat_dir)) {
            mkdir($coach_chat_dir, 0777, true);
        }

        // Enregistrement du chemin du fichier de chat dans la session
        $_SESSION['coach_chat_file'] = $coach_chat_dir . 'log' . $coach_id . '.html';
    } else {
        echo '<div class="container">';
        echo '<h2>Coach introuvable.</h2>';
        echo '</div>';
    }
} else {
    echo '<div class="container">';
    echo '<h2>Coach non sélectionné.</h2>';
    echo '</div>';
}

if (isset($_GET['logout'])) {
   // Message de sortie simple
 $logout_message = "<div class='msgln'><span class='left-info'>L'utilisateur <b class='user-name-left'>" .
 $_SESSION['name'] . "</b> a quitté la session de chat.</span><br></div>";

 $chat_file = $_SESSION['coach_chat_file'];
 $myfile = fopen($chat_file, "a") or die("Impossible d'ouvrir le fichier!" . $chat_file);
 fwrite($myfile, $logout_message);
 fclose($myfile);

 session_destroy();

 sleep(0.5);
   header("Location: activitesportive.php"); // Rediriger l'utilisateur
}

function loginForm()
{
 $_SESSION['name'] = "user1";
}

if (!isset($_SESSION['name'])) {
 loginForm();
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <<link rel="stylesheet" type="text/css" href="compte.css">
    <link rel="stylesheet" href="chat.css" />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <title>Sportify : Consultation Sportive</title>
    <link rel="icon" href="onglet.png" type="image/x-icon">
    <link rel="shortcut icon" href="onglet.png" type="image/x-icon">
    <script type="text/javascript">
        $(document).ready(function () {
            $('.header').height($(window).height());
        });
    </script>
    <script type="text/javascript">
        function scrollToSection(sectionId) {
            const section = document.querySelector(`#${sectionId}`);
            window.scrollTo({
                top: section.offsetTop,
                behavior: 'smooth'
            });
        }
    </script>
</head>
<nav class="navbar navbar-expand-md fixed-top">
    <a class="navbar-brand" href="accueil.php">
        <img id="logo" src="logo.png" height="80" width="200" alt="logo">
    </a>
    <button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="main-navigation">
        <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="accueil.php"><b>Accueil</b></a></li>
            <li class="nav-item"><a class="nav-link" href="ToutParcourir.php"><b>Tout Parcourir</b></a></li>
            <li class="nav-item"><a class="nav-link" href="recherchetest.php"><b>Recherche</b></a></li>
            <li class="nav-item"><a class="nav-link" href="rendezvous.php"><b>Rendez-vous</b></a></li>
        </ul>
        <?php
        if (isset($_SESSION["Role"])) {
          if ($_SESSION["Role"] === "Client") {
             echo '<a class="compte" href="pageclient.php">';
         } else if ($_SESSION["Role"] === "Coach") {
             echo '<a class="compte" href="pagecoach.php">';
         } else if ($_SESSION["Role"] === "Admin") {
             echo '<a class="compte" href="pageadmin.php">';
         } else {
             echo '<a class="compte" href="compte.php">';
         }
     } else {
      echo '<a class="compte" href="compte.php">';
  }
?><strong>Mon compte</strong></a>
</div>
</nav>

<body class="pt-5">

    <br><br><br><h2 style="text-align: center;">Discussion Coach: <b><?php echo $coach_name;?></h2></p>
     <div id="wrapper">
      <div id="menu">
       <p class="logout"><a id="exit" style="text-align: center;">ChatRoom</a></p>
   </div>
   <div id="chatbox">
       <?php
       $chat_file = $_SESSION['coach_chat_file'];
       if (file_exists($chat_file) && filesize($chat_file) > 0) {
        $contents = file_get_contents($chat_file);
        echo $contents;
    }
    ?>
</div>
<form name="message"  action="">
   <input name="usermsg" type="text" id="usermsg" />
   <input name="submitmsg" type="submit" id="submitmsg" value="Envoyer" />
   <a class="deco" href="deconnexion.php"><b>Déconnexion</b></a>
</form>
</div>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">
   // jQuery Document
 $(document).ready(function() {
  $("#submitmsg").click(function() {
   location.reload();
   var clientmsg = $("#usermsg").val();
   $.post("post_chatroom.php", { text: clientmsg }, function(response) {
    if (response.status === 'success') {
     $("#usermsg").val("");
     $("#chatbox").append(response.chat_content);

               // Faire défiler jusqu'au bas de la boîte de chat
     var chatbox = document.getElementById("chatbox");
     chatbox.scrollTop = chatbox.scrollHeight;
 } else {
     alert("Erreur lors de l'envoi du message : " + response.message);
 }
}, 'json');
   return false;
});

  function loadLog() {
         var oldscrollHeight = $("#chatbox")[0].scrollHeight - 20; //Hauteur de défilement avant la requête
         $.ajax({
            url: '<?php echo $coach_chat_dir . 'log' . $coach_id . '.html';?>',
            cache: false,
            success: function(html) {
               $("#chatbox").html(html); //Insérez le log de chat dans la #chatbox div
               //Auto-scroll
               var newscrollHeight = $("#chatbox")[0].scrollHeight - 20; //Hauteur de défilement apres la requête
               if (newscrollHeight > oldscrollHeight) {
                  $("#chatbox").animate({ scrollTop: newscrollHeight }, 'normal'); //Défilement automatique
              }
          }
      });
     }
     setInterval(loadLog, 2500);
 });
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    $(document).ready(function() {
            // Fonction pour actualiser la page
        function actualiserPage() {
            $.ajax({
                url: window.location.href,
                method: 'GET',
                success: function(data) {
                        $('body').html(data); // Mettre à jour le contenu de la page
                    }
                });
        }

            // Actualiser la page toutes les 5 secondes
        setInterval(actualiserPage, 10000);
    });
</script>



</body>

</html>