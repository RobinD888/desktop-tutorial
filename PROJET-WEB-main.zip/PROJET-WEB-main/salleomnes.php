<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sportify : Activité Sportive</title>

	<link rel="stylesheet" type="text/css" href="activitesportive.css">
	<link rel="stylesheet" type="text/css" href="salleomnes.css">


	<link rel="icon" href="onglet.png" type="image/x-icon">
	<link rel="shortcut icon" href="onglet.png" type="image/x-icon">

	<link rel="stylesheet"
	href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<script type="text/javascript">



		function showCV() {
        // Ouvrir la fenêtre modale
			$('#nos_services').modal('show');

		}

		function closeCVModal() {
        // Fermer la fenêtre modale
			$('#nos_services').modal('hide');
		}

	</script>


</head>
<body>
	<!-- barre du haut -->
	<nav class="navbar navbar-expand-md fixed-top"> 
		<a class="navbar-brand" href="accueil.php"> 
			<img id="logo" src="logo.png" height="80" width="200" alt="logo"> <!-- affichage du logo -->
		</a>
		<button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="main-navigation"> <!-- création du menu avec les différentes fonctionnalités -->
			<ul class="navbar-nav">
				<li class="nav-item"><a class="nav-link" href="accueil.php"><b>Accueil</b></a></li>
				<li class="nav-item"><a class="nav-link" href="ToutParcourir.php"><b>Tout Parcourir</b></a></li>
				<li class="nav-item"><a class="nav-link" href="recherchetest.php"><b>Recherche</b></a></li>
				<li class="nav-item"><?php
				if (isset($_SESSION["Role"])) {
					if ($_SESSION["Role"] === "Coach") {
						echo '<a class="nav-link" href="rendezvouscoach.php">';
					} else if ($_SESSION["Role"] === "Admin") {
						echo '<a class="nav-link" href="accueil.php">';
					} else {
						echo '<a class="nav-link" href="rendezvous.php">';
					}
				} else {
					echo '<a class="nav-link" href="rendezvous.php">';
				}
			?><b>Rendez-vous</b></a></li>
			<li class="nav-item2"><?php
			if (isset($_SESSION["Role"])) {
				if ($_SESSION["Role"] === "Client") {
					echo '<a class="compte" href="pageclient.php">';
				} else if ($_SESSION["Role"] === "Coach") {
					echo '<a class="compte" href="pagecoach.php">';
				} else if ($_SESSION["Role"] === "Admin") {
					echo '<a class="compte" href="pageadmin.php">';
				} else {
					echo '<a class="compte" href="compte.php">';
				}
			} else {
				echo '<a class="compte" href="compte.php">';
			}
		?><strong>Mon compte</strong></a></li>
	</ul>

</div>
</nav>



<!-- Boutons de sélection d'activité -->
<section class="activite">
	<div class="container-features" style="margin-top: 100px;">
		<div class="space"></div>
		<h3 style="text-align: center;"> Notre Salle Omnes </h3>
		<div class="space"></div>
		<div class="container features" >
			<div class="row">
				<?php
	// Identifiant de la base de données
				$database = "projet";

	// Connexion à la base de données
				$db_handle = mysqli_connect('localhost', 'root', '');
				$db_found = mysqli_select_db($db_handle, $database);

		// Si la base de données existe
				if ($db_found) {
					
					$sql = "SELECT * FROM etablissement WHERE Nom = 'Omnes'";

					$result = mysqli_query($db_handle, $sql);


			// Affichage des résultats
					if (mysqli_num_rows($result) > 0) {

						while ($data = mysqli_fetch_assoc($result)) {

							$_SESSION['salle_id'] = $data['ID'];
							$_SESSION['salle_nom'] = $data['Nom'];
							$_SESSION['salle_adresse'] = $data['Adresse'];
							$_SESSION['salle_service'] = $data['Service'];
							$_SESSION['salle_telephone'] = $data['Telephone'];
							$_SESSION['salle_mail'] = $data['Mail'];

							echo '<div class="col-sm-8 mx-auto text-center">';
        // Conteneur flexible pour centrer la photo

							echo '<img src="sallesport.jpg" alt="Photo de salle" height="300" width="500">';

							echo '<h4><strong>'. $data['Nom'] .'</strong></h4>';

							echo '<strong>Service :</strong> ' . $data['Service'] .'<br>';
							echo '<strong>Adresse :</strong> ' . $data['Adresse'] .'<br>';
							echo '<strong>Telephone : </strong>' . $data['Telephone'] .'<br>';
							echo '<strong>Mail : </strong>' . $data['Mail'] .'<br>';
							echo '<p></p>';
							echo '<a href="#" onclick="showCV()"><button type="button" class="btn btn-success">Nos Service</button></a>';
							echo '</div>';

						}

    echo '</div>'; // Fermeture de la classe row
    echo '</div>';
} else {
	echo '<div class="container">';
	echo '<h2>Aucun résultat trouvé.</h2>';
	echo '</div>';
}


} else {
	echo '<div class="container">';
	echo '<h2>Erreur : Base de données non trouvée.</h2>';
	echo '</div>';
}


	// Fermer la connexion à la base de données
mysqli_close($db_handle);
?>
</div>
</div>
</div>
<div class="space"></div>
</section>


<footer class="page-footer">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-3">
				<!-- Logo et liens vers les réseaux sociaux -->
				<img style="margin: 0px; padding: 0px;" id="logo" src="logo.png" height="80" width="200" alt="logo">
				<ul class="site">
					<li>
						<a href="https://www.facebook.com/" target="_blank" rel="noreferrer"><img alt="Facebook" src="fb.png" style="margin: 0px; padding: 0px;" width="24" height="24" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
					</li>
					<li>
						<a href="https://www.instagram.com/" target="_blank" rel="noreferrer"><img alt="instagram" src="insta.png" style="margin: 0px; padding: 0px;" width="24" height="24" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
					</li>
					<li>
						<a href="https://www.youtube.com/" target="_blank" rel="noreferrer"><img alt="youtube" src="https://clipart-library.com/images/dc4LABqni.png" style="margin: 0px; padding: 0px;" width="24" height="20" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
					</li>
				</ul>
			</div>
			<div class="col-lg-3" style="margin: 0px; padding: 0px; margin-left: 10px;">
				<!-- Informations additionnelles -->
				<h6 class="text-uppercase font-weight-bold">Information additionnelle</h6>
				<p style="text-align:justify;">
					Ce site utilise des cookies pour vous garantir la meilleure expérience. En poursuivant votre consultation, vous acceptez l’utilisation de ces cookies.
				</p>
			</div>
			<div class="col-lg-2" style="height:200px; background-color: transparent; margin-left: 30px;">
				<!-- Coordonnées de contact -->
				<h6 class="text-uppercase font-weight-bold">Contact</h6>
				<p>
					37, quai de Grenelle, 75015 Paris, France <br>
					sportify@webDynamique.ece.fr <br>
					+33 01 02 03 04 05 <br>
					+33 01 03 02 05 04
				</p>
			</div>
			<div class="col-lg-3" style="margin-left: 60px;">
				<!-- Carte Google Maps -->
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2143.576303287504!2d2.330437179343684!3d48.88009498207702!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66fa5dfd6b41f%3A0x1d20fbfc12fb96af!2sSpotify%20France%20SAS!5e0!3m2!1sfr!2sfr!4v1685467388920!5m2!1sfr!2sfr" width="250" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
			</div>
		</div>
		<div class="footer-copyright text-center">
			&copy; 2019 Copyright | Droit d'auteur:
			webDynamique.ece.fr
		</div>
	</div>
</footer>
<!-- Fenêtre modale pour afficher le CV -->
<div class="modal" id="nos_services" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" style="text-align: center;">Nos services</h5>

				<button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="closeCVModal()">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="accordion" id="accordionExample">
					<div class="card">
						<div class="card-header" id="headingOne">
							<h2 class="mb-0">
								<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne" style="color: black;">
									Horaire de la salle Omnes
								</button>
							</h2>
						</div>

						<div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
							<div class="horaires">
								
								<br>
								<p>Notre salle de sport est ouverte pour vous <strong style=" background-image: linear-gradient(98deg, #00E1FD, #FC007A 100%);
								-webkit-background-clip: text;
								-webkit-text-fill-color: transparent;">7j/7</strong> vous proposant un large choix d'activités, avec les horaires suivants :</p>
								<br>

								<ul>
									<li><strong>Lundi:</strong> 6h - 22h</li>
									<li><strong>Mardi:</strong> 6h - 22h</li>
									<li><strong>Mercredi:</strong> 6h - 22h</li>
									<li><strong>Jeudi:</strong> 6h - 22h</li>
									<li><strong>Vendredi:</strong> 6h - 22h</li>
									<li><strong>Samedi:</strong> 8h - 20h</li>
									<li><strong>Dimanche:</strong> 10h - 18h</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="card">
						<div class="card-header" id="headingTwo">
							<h2 class="mb-0">
								<button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapse2" aria-expanded="false" aria-controls="collapse2" style="color: black;">
									Visiter la salle Omnes
								</button>
							</h2>
						</div>
						<div id="collapse2" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
							<div class="card-body">
								<h5> <strong style=" background-image: linear-gradient(98deg, #00E1FD, #FC007A 100%);
								-webkit-background-clip: text;
								-webkit-text-fill-color: transparent;">Visitez notre salle de sport</strong> - Réservez votre créneau dès maintenant</h5>

								<p style="text-align: justify;">Nous sommes ravis de vous inviter à visiter notre salle de sport. Vous pouvez découvrir nos installations et rencontrer notre équipe en réservant un créneau qui vous convient :</p>

								<p style="text-align: justify;">Cliquez sur le bouton ci-dessous pour accéder à notre système de réservation en ligne :</p>

								<div class="text-center"> <!-- Ajout de la classe "text-center" pour centrer le contenu -->
									<a href="activitesportive.php">
										<button style="background : linear-gradient(98deg, #00E1FD, #FC007A 100%); color: white;" type="button" class="btn">
											Réserver un créneau
										</button>
									</a>
								</div>
								<p style="text-align: justify;">Une fois sur notre système de réservation, choisissez la date et l'heure qui vous conviennent le mieux. Notre équipe sera présente pour vous accueillir et répondre à toutes vos questions.</p>

								<p style="text-align: justify;">Ne manquez pas cette occasion de découvrir notre salle de sport et de prendre une décision éclairée pour rejoindre notre communauté active et en bonne santé.</p>
								
							</div>
						</div>
					</div>

					<div class="card">
						<div class="card-header" id="heading3">
							<h2 class="mb-0">
								<button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapse3" aria-expanded="false" aria-controls="collapse3" style="color: black;">
									Règles sur 
									l’utilisation des machines
								</button>
							</h2>
						</div>
						<div id="collapse3" class="collapse" aria-labelledby="heading3" data-parent="#accordionExample">
							<div class="card-body">
								<p style="text-align: justify;" > <strong>Bienvenue dans notre salle de sport Omnes !</strong> Pour vous aider à maximiser votre séance d'entraînement, voici <strong style=" background-image: linear-gradient(98deg, #00E1FD, #FC007A 100%);
								-webkit-background-clip: text;
								-webkit-text-fill-color: transparent;">un guide pratique</strong> pour utiliser correctement certaines des machines les plus courantes :</p>

								<h6><u>Tapis de course </u><img src="tapis.png" height="60" width="70"style="margin:0px"> </h6>
								<p style="text-align: justify;">Le tapis de course est idéal pour les <strong>exercices cardiovasculaires</strong>. Assurez-vous de régler la vitesse et l'inclinaison selon votre niveau de confort. Commencez par un échauffement de 5 minutes à une vitesse modérée, puis augmentez progressivement l'intensité.</p>

								<h6><u>Vélo elliptique</u> <img src="elliptique.png" height="60" width="70"style="margin:0px"> </h6>
								<p style="text-align: justify;">Le vélo elliptique offre un entraînement à faible impact pour <strong>renforcer</strong> les muscles des jambes et des bras. Tenez-vous droit, saisissez fermement les poignées et pédalez avec fluidité. Utilisez les réglages de résistance pour intensifier votre séance.</p>

								<h6><u>Machine à ramer</u> <img src="rameur.png" height="60" width="70"style="margin:0px"></h6>
								<p style="text-align: justify;">La machine à ramer est un excellent <strong>exercice complet du corps</strong>. Asseyez-vous avec le dos bien droit, attrapez la barre avec les mains et poussez avec les jambes tout en tirant avec les bras. Réglez la résistance en fonction de votre niveau de difficulté souhaité.</p>

								<h6> <u>La Leg Press </u><img src="presse.png" height="60" width="70"style="margin:0px"></h6>
								<p style="text-align: justify;">La machine Leg Press est un excellent moyen de renforcer <strong>les muscles des jambes</strong>, en particulier les quadriceps, les ischio-jambiers et les fessiers. Voici comment l'utiliser correctement :</p>
								<ol>
									<li>Asseyez-vous sur le siège de la machine, le dos bien appuyé contre le dossier.</li>
									<li>Placez les pieds sur la plateforme à une largeur d'épaules, les orteils légèrement tournés vers l'extérieur.</li>
									<li>Déverrouillez les arrêts de sécurité en poussant avec les pieds.</li>
									<li>Fléchissez les genoux et abaissez la plateforme vers votre corps en gardant le dos droit.</li>
									<li>Descendez jusqu'à ce que vos genoux soient fléchis à environ 90 degrés, sans les verrouiller.</li>
									<li>Expirez et poussez la plateforme avec vos talons pour revenir à la position de départ, en gardant le contrôle du mouvement.</li>
									<li>Répétez le mouvement pour le nombre de répétitions souhaité.</li>
								</ol>
								<p style="text-align: justify;">Il est important de respecter une bonne technique pour éviter les blessures :</p>
								<ul>
									<li>Maintenez votre dos appuyé contre le dossier tout au long de l'exercice.</li>
									<li>Ne verrouillez pas vos genoux en position étendue.</li>
									<li>Contrôlez le mouvement en évitant les secousses ou les mouvements rapides.</li>
									<li>Utilisez une charge appropriée en fonction de votre niveau de force et de votre capacité.</li>
								</ul>
								<h6><u>La Lat Pulldown </u><img src="lat.png" height="60" width="70"style="margin:0px"> </h6>


								<p style="text-align: justify;">La machine Lat Pulldown est parfaite pour renforcer les <strong>muscles du dos</strong>, en particulier les muscles du grand dorsal. Voici comment l'utiliser correctement :</p>

								<ol>
									<li>Asseyez-vous sur le siège de la machine, les cuisses bien calées sous les rouleaux de support.</li>
									<li>Attrapez la barre de traction avec une prise large, les paumes des mains tournées vers l'avant.</li>
									<li>Assurez-vous que vos pieds sont bien à plat sur le sol et que votre dos est droit.</li>
									<li>En expirant, tirez la barre vers le bas en gardant les coudes près du corps.</li>
									<li>Continuez à tirer jusqu'à ce que la barre soit en dessous de votre menton et que vos omoplates soient bien contractées.</li>
									<li>Inspirez et relâchez lentement la barre en la laissant remonter jusqu'à la position de départ.</li>
									<li>Répétez le mouvement pour le nombre de répétitions souhaité.</li>
								</ol>

								<p style="text-align: justify;">Voici quelques points à garder à l'esprit lors de l'utilisation de la machine Lat Pulldown :</p>

								<ul>
									<li>Ne pas balancer le corps pour générer de l'élan, utilisez uniquement la force des muscles du dos.</li>
									<li>Maintenez une position stable en contractant les abdominaux et en gardant le dos droit.</li>
									<li>Contrôlez le mouvement en évitant les mouvements brusques ou rapides.</li>
									<li>Utilisez une charge appropriée en fonction de votre niveau de force et de votre capacité.</li>
								</ul>

							</div>
						</div>
					</div>
					<div class="card">
						<div class="card-header" id="headingTwo">
							<h2 class="mb-0">
								<button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapse4" aria-expanded="false" aria-controls="collapse4" style="color: black;">
									Pour les nouveaux clients
								</button>
							</h2>
						</div>
						<div id="collapse4" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
							<div class="card-body">
								<h5> <strong style= " text-align: center; background-image: linear-gradient(98deg, #00E1FD, #FC007A 100%);
								-webkit-background-clip: text;
								-webkit-text-fill-color: transparent;">Offre spéciale pour les nouveaux clients </strong> - Essayez notre salle de sport dès maintenant</h5>

								<p style="text-align: justify;">Bienvenue dans notre salle de sport ! Nous sommes ravis de vous accueillir en tant que nouveau client. Pour vous aider à commencer votre parcours fitness de la meilleure façon possible, nous vous proposons une offre spéciale :</p>

								<h6><u>Séance d'essai avec un coach gratuit</u></h6>
								<p style="text-align: justify;">Profitez d'une séance d'essai gratuite avec l'un de nos coachs expérimentés. Ils vous guideront et vous montreront comment utiliser correctement les machines et vous conseilleront sur votre programme d'entraînement personnalisé.</p>

								<h6><u>Abonnement de 3 mois à 22.99 euros</u></h6>
								<p style="text-align: justify;">Après votre séance d'essai, vous pouvez bénéficier d'un abonnement spécial de 3 mois pour seulement 22.99 euros. Cela vous donne un accès complet à toutes nos installations et à nos cours collectifs. C'est une occasion idéale pour vous engager dans une routine d'exercice régulière.</p>

								<h6><u>Satisfait ou remboursé</u></h6>
								<p style="text-align: justify;">Nous sommes convaincus que vous allez adorer votre expérience dans notre salle de sport. Cependant, nous voulons vous offrir une tranquillité d'esprit supplémentaire. Si, pour une raison quelconque, vous n'êtes pas entièrement satisfait de votre abonnement dans les 30 premiers jours, nous vous rembourserons intégralement, sans poser de questions.</p>

								<p style="text-align: justify;">N'attendez plus ! Rejoignez-nous dès maintenant et profitez de cette offre exceptionnelle pour commencer votre voyage vers une meilleure forme physique et un bien-être total.</p>

							</div>
						</div>
					</div>
					<div class="card">
						<div class="card-header" id="headingTwo">
							<h2 class="mb-0">
								<button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapse5" aria-expanded="false" aria-controls="collapse5" style="color: black;"> 
									Alimentation et nutrition
								</button>
							</h2>
						</div>
						<div id="collapse5" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
							<div class="card-body">
								<article><p><h5> <strong style= " text-align: center; background-image: linear-gradient(98deg, #00E1FD, #FC007A 100%);
								-webkit-background-clip: text;
								-webkit-text-fill-color: transparent;">Alimentation et Nutrition - Conseils pour une vie saine</strong></h5> 
								<br />L'alimentation est primordiale et malheureusement souvent mal comprise lorsque l&rsquo;on fait r&eacute;f&eacute;rence au sport et &agrave; la sant&eacute;.&nbsp;<strong>Sportify</strong> vous propose un espace suppl&eacute;ments et des suivis personnalis&eacute;s afin de lier votre sant&eacute; &agrave; vos objectifs.</p>

								<p style="text-align: justify;">Une alimentation équilibrée joue un rôle essentiel dans le maintien d'une vie saine et énergique. Voici quelques conseils pour vous aider à adopter de bonnes habitudes alimentaires :</p>

								<h6><u>Mangez une variété d'aliments</u> <img src="variete.jpeg" height="60" width="70"style="margin:0px; border-radius: 50px;"></h6>
								<p style="text-align: justify;">Assurez-vous de consommer une grande variété d'aliments provenant des différents groupes alimentaires : fruits, légumes, céréales complètes, protéines maigres et produits laitiers. Cela garantit un apport adéquat en nutriments essentiels.</p>

								<h6><u>Limitez les aliments transformés</u> <img src="frite.jpg" height="60" width="70"style="margin:0px; border-radius: 50px;"></h6>
								<p style="text-align: justify;">Les aliments transformés, riches en sucres ajoutés, en gras saturés et en sodium, peuvent avoir un impact négatif sur votre santé. Essayez de limiter votre consommation de ces aliments et privilégiez les aliments frais et non transformés.</p>

								<h6><u>Contrôlez les portions</u> <img src="portion.jpg" height="60" width="70"style="margin:0px; border-radius: 50px;"></h6>
								<p style="text-align: justify;">Portez une attention particulière aux portions que vous consommez. Apprenez à reconnaître les portions recommandées pour chaque type d'aliment et essayez de vous en tenir à ces quantités pour éviter les excès caloriques.</p>

								<h6><u>Hydratez-vous adéquatement</u> <img src="eau.jpeg" height="60" width="70"style="margin:0px; border-radius: 50px;"></h6>
								<p style="text-align: justify;">La consommation d'eau est cruciale pour maintenir une bonne hydratation. Buvez suffisamment d'eau tout au long de la journée et limitez votre consommation de boissons sucrées et de boissons alcoolisées.</p>

								<h6><u>Privilégiez les cuissons saines</u><img src="cuisson.jpeg" height="60" width="70"style="margin:0px; border-radius: 50px;"></h6>
								<p style="text-align: justify;">Optez pour des méthodes de cuisson saines comme la cuisson à la vapeur, la cuisson au four ou la cuisson à la poêle avec peu de matières grasses. Évitez les fritures et les cuissons excessivement grasses.</p>

								<h6><u>Écoutez votre corps</u> <img src="corps.jpg" height="60" width="70"style="margin:0px; border-radius: 50px;"></h6>
								<p style="text-align: justify;">Apprenez à écouter les signaux de votre corps. Mangez lorsque vous avez faim et arrêtez de manger lorsque vous vous sentez rassasié. Soyez attentif à vos sensations de satiété et évitez de manger par ennui ou par habitude.</p>

								<p style="text-align: justify;">Adopter une alimentation saine et équilibrée peut avoir un impact positif sur votre bien-être général. Prenez soin de votre alimentation et vous verrez les bienfaits sur votre santé physique et mentale.</p>

							</article>
						</div>
					</div>
				</div>

				<!-- Add more cards for additional sections -->

			</div>
		</div>

	</div>
</div>
</div>
</body>
</html>

