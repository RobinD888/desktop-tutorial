function annulerRendezVous(rdvID) {
    // confirmation de l'annulation du rendez-vous
    var confirmation = confirm("Êtes-vous sûr de vouloir annuler ce rendez-vous ?");

    if (confirmation) { // si la confirmation est validé alors on annule le rendez-vous
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'annuler_rdv.php', true); // appelle du programme qui permet d'annuler le rdv
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) { // message d'alerte que le rendez est validé
                alert("Le rendez-vous a été annulé avec succès.");
                location.reload();
            }
        };
        xhr.send('rdvID=' + rdvID);
    }
}