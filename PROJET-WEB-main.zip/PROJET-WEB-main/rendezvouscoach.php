<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Rendez-vous</title>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="accueil.css">
    <link rel="stylesheet" type="text/css" href="rendezvous.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="annulerrdv.js"></script>
    <title>Sportify : Consultation Sportive</title>
    <link rel="icon" href="onglet.png" type="image/x-icon">
    <link rel="shortcut icon" href="onglet.png" type="image/x-icon">
    <script type="text/javascript">
        $(document).ready(function () {
            $('.header').height($(window).height());
        });
    </script>
    <script type="text/javascript">
        function scrollToSection(sectionId) {
            const section = document.querySelector(`#${sectionId}`);
            window.scrollTo({
                top: section.offsetTop,
                behavior: 'smooth'
            });
        }
    </script>

</head>

<body class="pt-5">
    <nav class="navbar navbar-expand-md fixed-top">
        <a class="navbar-brand" href="acceuil.html">
            <img id="logo" src="logo.png" height="80" width="200" alt="logo">
        </a>
        <button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="main-navigation">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="accueil.php"><b>Accueil</b></a></li>
                <li class="nav-item"><a class="nav-link" href="ToutParcourir.php"><b>Tout Parcourir</b></a></li>
                <li class="nav-item"><a class="nav-link" href="recherchetest.php"><b>Recherche</b></a></li>
                <li class="nav-item">
                    <?php
                    if (isset($_SESSION["Role"])) {
                        if ($_SESSION["Role"] === "Coach") {
                            echo '<a class="nav-link" href="rendezvouscoach.php">';
                        } else if ($_SESSION["Role"] === "Admin") {
                            echo '<a class="nav-link" href="accueil.php">';
                        } else {
                            echo '<a class="nav-link" href="rendezvous.php">';
                        }
                    } else {
                        echo '<a class="nav-link" href="rendezvous.php">';
                    }
                    ?>
                    <b>Rendez-vous</b></a>
                </li>
                <li class="nav-item2">
                    <?php
                    if (isset($_SESSION["Role"])) {
                        if ($_SESSION["Role"] === "Client") {
                            echo '<a class="compte" href="pageclient.php">';
                        } else if ($_SESSION["Role"] === "Coach") {
                            echo '<a class="compte" href="pagecoach.php">';
                        } else if ($_SESSION["Role"] === "Admin") {
                            echo '<a class="compte" href="pageadmin.php">';
                        } else {
                            echo '<a class="compte" href="compte.php">';
                        }
                    } else {
                        echo '<a class="compte" href="compte.php">';
                    }
                ?><strong>Mon compte</strong></a>
            </li>
        </ul>

    </div>
</nav>
<div class="container" style="margin-top: 200px; margin-bottom: 200px;">

    <?php
        // Connexion à la base de données
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "projet";

    $conn = new mysqli($servername, $username, $password, $dbname);

        // Vérification de la connexion
    if ($conn->connect_error) {
        die("Erreur de connexion à la base de données : " . $conn->connect_error);
    }

        // Récupération de l'ID du coach
    $userID = $_SESSION["Email"];
        // Récupération des rendez-vous futurs du coach
    $queryFutur = "SELECT * FROM rdv WHERE ID_coach = '$userID' AND (Date >= CURDATE() OR Date = '0000-00-00') ORDER BY Date";
    $resultFutur = $conn->query($queryFutur);

    if ($resultFutur->num_rows > 0) {
        echo "<h2>Vos rendez-vous à venir :</h2>";
        while ($row = $resultFutur->fetch_assoc()) {
            $rdvID = $row['ID'];
            $date = $row['Date'];
            $heure = $row['Heure'];
            $salle = $row['Salle'];

                // Récupération des informations sur le client du rendez-vous
            $clientID = $row['ID_client'];
            $clientQuery = "SELECT * FROM users WHERE ID = $clientID";
            $clientResult = $conn->query($clientQuery);
            if ($clientResult->num_rows > 0) {
                $clientRow = $clientResult->fetch_assoc();
                $clientNom = $clientRow['Nom'];
                $clientPrenom = $clientRow['Prenom'];
                echo "<h3>Rendez-vous avec le client $clientPrenom $clientNom</h3>";
            }

            if ($date != '0000-00-00') {
                echo "<p>Date : $date</p>";
            }
            echo "<p>Heure : $heure</p>";
            if (!empty($salle)) {
                echo "<p>Salle : $salle</p>";
            }
            echo "<button onclick='annulerRendezVous($rdvID)'>Annuler RDV</button>";
            echo "<hr>";
        }
    } else {
        echo "<h2>Vous n'avez pas de rendez-vous à venir</h2>";
    }

        // Récupération des rendez-vous passés du coach
    $queryHistorique = "SELECT * FROM rdv WHERE ID_coach = '$userID' AND Date < CURDATE() AND Date != '0000-00-00' ORDER BY Date DESC";
    $resultHistorique = $conn->query($queryHistorique);

    if ($resultHistorique->num_rows > 0) {
        echo "<h2>Historique de vos rendez-vous :</h2>";
        while ($row = $resultHistorique->fetch_assoc()) {
            $rdvID = $row['ID'];
            $date = $row['Date'];
            $heure = $row['Heure'];
            $salle = $row['Salle'];

                // Récupération des informations sur le client du rendez-vous
            $clientID = $row['ID_client'];
            $clientQuery = "SELECT * FROM users WHERE ID = $clientID";
            $clientResult = $conn->query($clientQuery);
            if ($clientResult->num_rows > 0) {
                $clientRow = $clientResult->fetch_assoc();
                $clientNom = $clientRow['Nom'];
                $clientPrenom = $clientRow['Prenom'];
                echo "<h3>Rendez-vous avec le client $clientPrenom $clientNom</h3>";
            }

            if (!empty($date)) {
                echo "<p>Date : $date</p>";
            }
            echo "<p>Heure : $heure</p>";
            if (!empty($salle)) {
                echo "<p>Salle : $salle</p>";
            }
            echo "<hr>";
        }
    } else {
        echo "<h2>Vous n'avez pas d'ancien rendez-vous.</h2>";
    }

    $conn->close();
    ?>
</div>
</body>

</html>