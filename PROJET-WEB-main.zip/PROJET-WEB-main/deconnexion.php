<?php
header ("Location: compte.php")
?>