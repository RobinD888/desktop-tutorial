<?php
// Connexion à la base de données
$database = "projet";
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

// Vérification de la connexion
if ($db_found){
// Récupération de l'ID du rendez-vous à annuler
    $rdvID = $_POST['rdvID'];

// Supprimer le rendez-vous de la base de données
    $query = "DELETE FROM rdv WHERE ID = $rdvID";
    if (mysqli_query($db_handle, $query) === TRUE) {
        echo "Le rendez-vous a été annulé avec succès.";
    } else {
        echo "Erreur lors de l'annulation du rendez-vous : " . $conn->error;
    }
}
else {
    echo "Aucun résultat trouvé.";
}
mysqli_close($db_handle);
?>
