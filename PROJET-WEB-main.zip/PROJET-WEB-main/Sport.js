function loadXMLDoc(coachID) {
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
    // Request finished and response is ready and Status is "OK"
				if (this.readyState == 4) {
					if (this.status == 200) {
						var xmlData = this.responseXML;

            // Extraire et afficher les informations du CV à partir du fichier XML
						var formations = xmlData.getElementsByTagName("formation");
						var experiences = xmlData.getElementsByTagName("experience");
						var autres = xmlData.getElementsByTagName("autre");

            // Construction du contenu HTML pour la fenêtre modale
						var modalContent = '<h3>Formations</h3><ul>';
						for (var i = 0; i < formations.length; i++) {
							modalContent += '<li>' + formations[i].textContent + '</li>';
						}
						modalContent += '</ul>';

						modalContent += '<h3>Expériences</h3><ul>';
						for (var i = 0; i < experiences.length; i++) {
							modalContent += '<li>' + experiences[i].textContent + '</li>';
						}
						modalContent += '</ul>';

						modalContent += '<h3>Autres informations</h3><ul>';
						for (var i = 0; i < autres.length; i++) {
							modalContent += '<li>' + autres[i].textContent + '</li>';
						}
						modalContent += '</ul>';
					} else if (this.status == 404) {
						var modalContent = 'Le CV du coach n\'est pas disponible.';
					}

        // Affichage du contenu dans la fenêtre modale
					document.querySelector(".modal-body").innerHTML = modalContent;
				}
			};

// `cv_${coachID}.xml` est le nom du fichier XML correspondant au coach
			xmlhttp.open("GET", `cv_${coachID}.xml`, true);
			xmlhttp.send();
		}


		function showCV(coachID) {
        // Ouvrir la fenêtre modale
			$('#cvModal').modal('show');

        // Charger les informations du CV dans la fenêtre modale
			loadXMLDoc(coachID);
		}

		function closeCVModal() {
        // Fermer la fenêtre modale
			$('#cvModal').modal('hide');
		}
