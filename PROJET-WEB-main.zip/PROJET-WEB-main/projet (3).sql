-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Dim 04 Juin 2023 à 21:50
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `projet`
--

-- --------------------------------------------------------

--
-- Structure de la table `coach`
--

CREATE TABLE IF NOT EXISTS `coach` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(50) NOT NULL,
  `Prenom` varchar(50) NOT NULL,
  `Specialite` varchar(50) NOT NULL,
  `Photo` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `Salle` varchar(50) NOT NULL,
  `Telephone` varchar(50) NOT NULL,
  `CV` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=95 ;

--
-- Contenu de la table `coach`
--

INSERT INTO `coach` (`ID`, `Nom`, `Prenom`, `Specialite`, `Photo`, `mail`, `Salle`, `Telephone`, `CV`) VALUES
(1, 'Doe', 'John', 'Musculation', 'coach1.jpeg', 'john.doe@gmail.com', 'Salle1', '0601010101', 'cv_1.xml'),
(2, 'Smith', 'Anna', 'Cardio', 'coach2.jpeg', 'anna.smith@gmail.com', 'Salle2', '0602020202', 'cv_2.xml'),
(3, 'Taylor', 'Michael', 'Biking', 'coach3.jpeg', 'michael.taylor@gmail.com', 'Salle3', '0603030303', 'cv_3.xml'),
(4, 'Johnson', 'Sarah', 'Fitness', 'coach4.jpeg', 'sarah.johnson@gmail.com', 'Salle4', '0604040404', 'cv_4.xml'),
(5, 'Brown', 'David', 'Cours Collectifs', 'coach5.jpeg', 'david.brown@gmail.com', 'Salle5', '0605050505', 'cv_5.xml'),
(6, 'Davis', 'Emma', 'Basketball', 'coach6.jpeg', 'emma.davis@gmail.com', 'Salle6', '0606060606', 'cv_6.xml'),
(7, 'Miller', 'Oliver', 'Football', 'coach7.jpeg', 'oliver.miller@gmail.com', 'Salle7', '0607070707', 'cv_7.xml'),
(8, 'Wilson', 'Sophia', 'Rugby', 'coach8.jpeg', 'sophia.wilson@gmail.com', 'Salle8', '0608080808', 'cv_8.xml'),
(9, 'Moore', 'Benjamin', 'Tennis', 'coach9.jpeg', 'benjamin.moore@gmail.com', 'Salle9', '0609090909', 'cv_9.xml'),
(10, 'Clark', 'Emily', 'Natation', 'coach10.jpeg', 'emily.clark@gmail.com', 'Salle10', '0610101010', 'cv_10.xml'),
(11, 'Diver', 'Tom', 'Plongeon', 'coach11.jpeg', 'tom.diver@gmail.com', 'Salle11', '0611111111', 'cv_11.xml');

-- --------------------------------------------------------

--
-- Structure de la table `disponibilite`
--

CREATE TABLE IF NOT EXISTS `disponibilite` (
  `LundiAM` tinyint(1) NOT NULL DEFAULT '0',
  `LundiPM` tinyint(1) NOT NULL DEFAULT '0',
  `MardiAM` tinyint(1) NOT NULL DEFAULT '0',
  `MardiPM` tinyint(1) NOT NULL DEFAULT '0',
  `MercrediAM` tinyint(1) NOT NULL DEFAULT '0',
  `MercrediPM` tinyint(1) NOT NULL DEFAULT '0',
  `JeudiAM` tinyint(1) NOT NULL DEFAULT '0',
  `JeudiPM` tinyint(1) NOT NULL DEFAULT '0',
  `VendrediAM` tinyint(1) NOT NULL DEFAULT '0',
  `VendrediPM` tinyint(1) NOT NULL DEFAULT '0',
  `SamediAM` tinyint(1) NOT NULL DEFAULT '0',
  `SamediPM` tinyint(1) NOT NULL DEFAULT '0',
  `DimancheAM` tinyint(1) NOT NULL DEFAULT '0',
  `DimanchePM` tinyint(1) NOT NULL DEFAULT '0',
  `ID_Coach` varchar(50) NOT NULL,
  PRIMARY KEY (`ID_Coach`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `disponibilite`
--

INSERT INTO `disponibilite` (`LundiAM`, `LundiPM`, `MardiAM`, `MardiPM`, `MercrediAM`, `MercrediPM`, `JeudiAM`, `JeudiPM`, `VendrediAM`, `VendrediPM`, `SamediAM`, `SamediPM`, `DimancheAM`, `DimanchePM`, `ID_Coach`) VALUES
(1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 'anna.smith@gmail.com'),
(1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 'benjamin.moore@gmail.com'),
(1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 'david.brown@gmail.com'),
(1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 'emily.clark@gmail.com'),
(1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 'emma.davis@gmail.com'),
(1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 'john.doe@gmail.com'),
(1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 'michael.taylor@gmail.com'),
(1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 'oliver.miller@gmail.com'),
(1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 'sarah.johnson@gmail.com'),
(1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 'sophia.wilson@gmail.com'),
(0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 'tom.diver@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `etablissement`
--

CREATE TABLE IF NOT EXISTS `etablissement` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(50) NOT NULL,
  `Adresse` varchar(50) NOT NULL,
  `Service` varchar(50) NOT NULL,
  `Telephone` varchar(50) NOT NULL,
  `Mail` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=13 ;

--
-- Contenu de la table `etablissement`
--

INSERT INTO `etablissement` (`ID`, `Nom`, `Adresse`, `Service`, `Telephone`, `Mail`) VALUES
(3, 'Omnes', '123 rue de Paris', 'Fitness', '0101010101', 'contact@fitnesspark.fr'),
(4, 'Basic Fit', '456 boulevard de Strasbourg', 'Fitness', '0202020202', 'contact@basicfit.fr'),
(5, 'Keep Cool', '789 avenue de la République', 'Fitness', '0303030303', 'contact@keepcool.fr'),
(6, 'Neoness', '147 rue du Faubourg Saint-Antoine', 'Fitness', '0404040404', 'contact@neoness.fr'),
(7, 'CMG Sports Club', '258 boulevard Saint-Germain', 'Fitness', '0505050505', 'contact@cmgsportsclub.fr'),
(8, 'Orange Bleue', '369 rue de Belleville', 'Fitness', '0606060606', 'contact@lorangebleue.fr'),
(9, 'Amazonia', '741 avenue Jean Jaurès', 'Fitness', '0707070707', 'contact@amazonia.fr'),
(10, 'Club Med Gym', '852 boulevard de la Villette', 'Fitness', '0808080808', 'contact@clubmedgym.fr'),
(11, 'Fitness First', '963 rue de la Roquette', 'Fitness', '0909090909', 'contact@fitnessfirst.fr'),
(12, 'CrossFit Original Addicts', '147 rue Oberkampf', 'CrossFit', '0101010101', 'contact@crossfitoriginaladdicts.fr');

-- --------------------------------------------------------

--
-- Structure de la table `paiements`
--

CREATE TABLE IF NOT EXISTS `paiements` (
  `PaiementID` int(11) NOT NULL AUTO_INCREMENT,
  `ClientID` int(11) NOT NULL,
  `TypeCarte` varchar(50) NOT NULL,
  `NumCarte` int(11) NOT NULL,
  `NomCarte` varchar(50) NOT NULL,
  `DateExp` date NOT NULL,
  `CodeSecu` int(11) NOT NULL,
  `Valide` int(11) NOT NULL,
  `TransactionTerminee` int(11) NOT NULL,
  PRIMARY KEY (`PaiementID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `paiements`
--

INSERT INTO `paiements` (`PaiementID`, `ClientID`, `TypeCarte`, `NumCarte`, `NomCarte`, `DateExp`, `CodeSecu`, `Valide`, `TransactionTerminee`) VALUES
(1, 1, 'zetzte', 0, 'sdgs', '0000-00-00', 0, 1, 1),
(2, 1, 'qrfqf', 0, 'qsfsq', '0000-00-00', 0, 1, 1),
(3, 1, 'dsqd', 0, 'qdq', '0000-00-00', 0, 1, 1),
(4, 1, 'sfqf', 0, 'qdfdqfq', '0000-00-00', 0, 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `rdv`
--

CREATE TABLE IF NOT EXISTS `rdv` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_coach` varchar(50) NOT NULL,
  `ID_client` int(11) NOT NULL,
  `Jour` varchar(50) NOT NULL,
  `Heure` varchar(50) NOT NULL,
  `Information` varchar(50) NOT NULL,
  `Salle` varchar(50) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=37 ;

--
-- Contenu de la table `rdv`
--

INSERT INTO `rdv` (`ID`, `ID_coach`, `ID_client`, `Jour`, `Heure`, `Information`, `Salle`, `Date`) VALUES
(27, 'john.doe@gmail.com', 1, 'Jeudi', '10', ' ', 'Salle1', '0000-00-00'),
(30, 'john.doe@gmail.com', 1, 'Vendredi', '14', ' ', 'Salle1', '0000-00-00'),
(34, 'john.doe@gmail.com', 1, 'Samedi', '11', ' ', 'Salle1', '0000-00-00'),
(35, 'john.doe@gmail.com', 1, 'Mercredi', '11', ' ', 'Salle1', '0000-00-00'),
(36, 'anna.smith@gmail.com', 1, 'Mercredi', '14', ' ', 'Salle2', '0000-00-00');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(50) NOT NULL,
  `Prenom` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Role` varchar(50) NOT NULL,
  `AdresseL1` varchar(50) NOT NULL,
  `AdresseL2` varchar(50) NOT NULL,
  `CodePostal` int(11) NOT NULL,
  `Pays` varchar(50) NOT NULL,
  `Ville` varchar(50) NOT NULL,
  `Telephone` varchar(50) NOT NULL,
  `Etudiant` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=24 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`ID`, `Nom`, `Prenom`, `Email`, `Password`, `Role`, `AdresseL1`, `AdresseL2`, `CodePostal`, `Pays`, `Ville`, `Telephone`, `Etudiant`) VALUES
(1, '', '', 'user@gmail.com', 'pass', 'Client', '', '', 0, '', '', '', ''),
(7, '', '', 'admin@gmail.com', 'pass', 'Admin', '', '', 0, '', '', '', ''),
(13, 'Doe', 'John', 'john.doe@gmail.com', 'password1', 'Coach', 'Adresse1', '', 75000, 'France', 'Paris', '0601010101', '0'),
(14, 'Smith', 'Anna', 'anna.smith@gmail.com', 'password2', 'Coach', 'Adresse2', '', 75000, 'France', 'Paris', '0602020202', '0'),
(15, 'Taylor', 'Michael', 'michael.taylor@gmail.com', 'password3', 'Coach', 'Adresse3', '', 75000, 'France', 'Paris', '0603030303', '0'),
(16, 'Johnson', 'Sarah', 'sarah.johnson@gmail.com', 'password4', 'Coach', 'Adresse4', '', 75000, 'France', 'Paris', '0604040404', '0'),
(17, 'Brown', 'David', 'david.brown@gmail.com', 'password5', 'Coach', 'Adresse5', '', 75000, 'France', 'Paris', '0605050505', '0'),
(18, 'Davis', 'Emma', 'emma.davis@gmail.com', 'password6', 'Coach', 'Adresse6', '', 75000, 'France', 'Paris', '0606060606', '0'),
(19, 'Miller', 'Oliver', 'oliver.miller@gmail.com', 'password7', 'Coach', 'Adresse7', '', 75000, 'France', 'Paris', '0607070707', '0'),
(20, 'Wilson', 'Sophia', 'sophia.wilson@gmail.com', 'password8', 'Coach', 'Adresse8', '', 75000, 'France', 'Paris', '0608080808', '0'),
(21, 'Moore', 'Benjamin', 'benjamin.moore@gmail.com', 'password9', 'Coach', 'Adresse9', '', 75000, 'France', 'Paris', '0609090909', '0'),
(22, 'Clark', 'Emily', 'emily.clark@gmail.com', 'password10', 'Coach', 'Adresse10', '', 75000, 'France', 'Paris', '0610101010', '0'),
(23, 'Diver', 'Tom', 'tom.diver@gmail.com', 'password11', 'Coach', 'Adresse11', '', 75000, 'France', 'Paris', '0611111111', '0');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
