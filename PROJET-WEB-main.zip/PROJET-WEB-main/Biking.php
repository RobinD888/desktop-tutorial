<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sportify : Activité Sportive</title>

	<link rel="stylesheet" type="text/css" href="activitesportive.css">


	<link rel="icon" href="onglet.png" type="image/x-icon">
	<link rel="shortcut icon" href="onglet.png" type="image/x-icon">

	<link rel="stylesheet"
	href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<script src="sport.js" type="text/javascript"></script>


</head>
<body>
	<!-- barre du haut -->
	<nav class="navbar navbar-expand-md fixed-top"> 
		<a class="navbar-brand" href="accueil.php"> 
			<img id="logo" src="logo.png" height="80" width="200" alt="logo"> <!-- affichage du logo -->
		</a>
		<button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="main-navigation"> <!-- création du menu avec les différentes fonctionnalités -->
			<ul class="navbar-nav">
				<li class="nav-item"><a class="nav-link" href="accueil.php"><b>Accueil</b></a></li>
				<li class="nav-item"><a class="nav-link" href="ToutParcourir.php"><b>Tout Parcourir</b></a></li>
				<li class="nav-item"><a class="nav-link" href="recherchetest.php"><b>Recherche</b></a></li>
				<li class="nav-item"><?php
				if (isset($_SESSION["Role"])) {
					if ($_SESSION["Role"] === "Coach") {
						echo '<a class="nav-link" href="rendezvouscoach.php">';
					} else if ($_SESSION["Role"] === "Admin") {
						echo '<a class="nav-link" href="accueil.php">';
					} else {
						echo '<a class="nav-link" href="rendezvous.php">';
					}
				} else {
					echo '<a class="nav-link" href="rendezvous.php">';
				}
			?><b>Rendez-vous</b></a></li>
			<li class="nav-item2"><?php
			if (isset($_SESSION["Role"])) {
				if ($_SESSION["Role"] === "Client") {
					echo '<a class="compte" href="pageclient.php">';
				} else if ($_SESSION["Role"] === "Coach") {
					echo '<a class="compte" href="pagecoach.php">';
				} else if ($_SESSION["Role"] === "Admin") {
					echo '<a class="compte" href="pageadmin.php">';
				} else {
					echo '<a class="compte" href="compte.php">';
				}
			} else {
				echo '<a class="compte" href="compte.php">';
			}
		?><strong>Mon compte</strong></a></li>
	</ul>

</div>
</nav>

<!-- Boutons de sélection d'activité -->
<section class="activite">
	<div class="container-features" style="margin-top: 100px;">
		<div class="space"></div>
		<h1 style="text-align: center;"> <strong style= " text-align: center; background-image: linear-gradient(98deg, #00E1FD, #FC007A 100%);
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;">Bicking </strong>-  Une expérience de cyclisme en salle intense</h1>
		<div class="space"></div>
		<div class="row"> <!-- Add justify-content-center class to center the row -->
			<div class="col-sm-8 mx-auto"> 

				<div class="d-flex justify-content-center">
					<img src="https://www.interval.fr/wp-content/uploads/2021/09/Biking-1280x854.jpg" height="350" width="500" style="margin: 0 auto; border-radius: 8px; ">
				</div>
				<br>
				<p style="text-align: justify;">Le biking est une activité de cyclisme en salle qui combine le plaisir du vélo avec un entraînement cardio intense. Cette pratique populaire est réalisée sur des vélos d'intérieur spécialement conçus, souvent en groupe et accompagnée de musique entraînante.</p>

				<h5>Les avantages du Biking</h5>

				<ul>
					<li style="text-align: justify;">Brûle des calories et favorise la perte de poids</li>
					<li style="text-align: justify;">Renforce les muscles des jambes, des fessiers et du noyau</li>
					<li style="text-align: justify;">Améliore la santé cardiovasculaire et l'endurance</li>
					<li style="text-align: justify;">Augmente la résistance et la force des jambes</li>
					<li style="text-align: justify;">Stimule la libération d'endorphines pour une sensation de bien-être</li>
				</ul>

				<h5>Comment pratiquer le Biking</h5>

				<p style="text-align: justify;">Voici quelques conseils pour profiter au maximum de vos séances de biking :</p>

				<ul>
					<li style="text-align: justify;">Ajustez correctement le vélo en fonction de votre taille et de votre position</li>
					<li style="text-align: justify;">Échauffez-vous avant chaque séance pour préparer votre corps à l'effort</li>
					<li style="text-align: justify;">Adaptez l'intensité de votre entraînement en fonction de votre niveau de forme physique</li>
					<li style="text-align: justify;">Suivez le rythme de la musique et utilisez-le comme source de motivation</li>
					<li style="text-align: justify;">Vérifiez votre posture et maintenez une bonne technique de pédalage</li>
					<li style="text-align: justify;">Hydratez-vous régulièrement pendant votre séance</li>
					<li style="text-align: justify;">Variez votre entraînement en alternant entre les périodes d'effort intense et de récupération</li>
					<li style="text-align: justify;">Étirez-vous après chaque séance pour favoriser la récupération musculaire</li>
				</ul>

				<h5>Les bienfaits de la communauté de Biking</h5>

				<p style="text-align: justify;">Outre les avantages physiques, le biking offre également une expérience sociale et communautaire :</p>

				<ul>
					<li style="text-align: justify;">Vous pouvez vous entraîner en groupe avec d'autres passionnés de biking</li>
					<li style="text-align: justify;">La musique et l'énergie de la salle créent une ambiance motivante</li>
					<li style="text-align: justify;">Vous pouvez vous fixer des objectifs communs et vous soutenir mutuellement</li>
					<li style="text-align: justify;">Les instructeurs de biking sont là pour vous guider et vous encourager</li>
				</ul>

				<p style="text-align: justify;">Le biking est une excellente façon de rester en forme, de brûler des calories et de se divertir en même temps. Que vous soyez un cycliste expérimenté ou un débutant, le biking peut être adapté à tous les niveaux. Alors, préparez-vous à transpirer, à pédaler avec passion et à vous sentir revigoré après chaque séance de biking</p>
			</div>
		</div>
		<?php
	// Identifiant de la base de données
		$database = "projet";

	// Connexion à la base de données
		$db_handle = mysqli_connect('localhost', 'root', '');
		$db_found = mysqli_select_db($db_handle, $database);

	// Vérification si un bouton a été cliqué

		if ($db_found) {

			$sql = "SELECT * FROM coach WHERE Specialite = 'biking'";


			$result = mysqli_query($db_handle, $sql);


			// Affichage des résultats
			if (mysqli_num_rows($result) > 0) {
				echo '<div class="container features">';
				echo'<div class="space"></div>';
				echo '<h2>Nos Coachs de Bicking : </h2>';
				echo '<div class="space"></div>';
    echo '<div class="row">'; // Ajout de la classe row

    while ($data = mysqli_fetch_assoc($result)) {

    	$_SESSION['coach_id'] = $data['ID'];
    	$_SESSION['coach_nom'] = $data['Nom'];
    	$_SESSION['coach_prenom'] = $data['Prenom'];
    	$_SESSION['coach_specialite'] = $data['Specialite'];
    	$_SESSION['coach_salle'] = $data['Salle'];
    	$_SESSION['coach_telephone'] = $data['Telephone'];
    	$_SESSION['coach_mail'] = $data['mail'];

    	echo '<div class="col-sm-6 text-center">';
        // Conteneur flexible pour centrer la photo

    	echo '<img src="' . $data['Photo'] . '" alt="Photo du coach" height="80" width="80">';

    	echo '<h5><strong>' . $data['Prenom'] .' '. $data['Nom'] .'</strong></h5>';
    	echo '<h6><strong>Coachs, ' . $data['Specialite'] .'</strong></h6><br>';
    	echo 'Salle: ' . $data['Salle'] .'<br>';
    	echo 'Telephone: ' . $data['Telephone'] .'<br>';
    	echo 'Mail : ' . $data['mail'] .'<br>';
    	if (isset($_SESSION["ID"])) {
    		$userID = $_SESSION['ID'];
    		if ($userID !== "") {
    			echo '<a href="index_chatroom.php?coach_id=' . $data['ID'] . '"><button type="button" class="btn btn-success">Communiquer avec le coach</button></a>';
    			echo '<form method="post" action="planning.php">
    			<input type="hidden" name="coach" value="' . $data['mail'] . '">
    			<button type="submit" class="btn btn-outline-primary">Prendre un Rendez-Vous</button>
    			</form>';
    		}else {

    			echo '<a href="compte.php"><button type="button" class="btn btn-success">Communiquer avec le coach</button></a><br>';
    			echo '<form method="post" action="compte.php">
    			<button type="submit" class="btn btn-outline-primary">Prendre un Rendez-Vous</button>
    			</form>';
    			
    		}
    	} else {
    		echo '<a href="compte.php"><button type="button" class="btn btn-success">Communiquer avec le coach</button></a><br>';
    		echo '<form method="post" action="compte.php">
    		<button type="submit" class="btn btn-outline-primary">Prendre un Rendez-Vous</button>
    		</form>';
    	}
    	echo '<a href="#" onclick="showCV('.$data["ID"].')">Voir le CV</a>';
    	echo '</div>';

    }

    echo '</div>'; // Fermeture de la classe row
    echo '</div>';
} else {
	echo '<div class="container">';
	echo '<h2>Aucun coach trouvé.</h2>';
	echo '</div>';
}


}else {
	echo '<div class="container">';
	echo '<h2>Erreur : Base de données non trouvée.</h2>';
	echo '</div>';
}


	// Fermer la connexion à la base de données
mysqli_close($db_handle);
?>


</div>
<div class="space"></div>
</section>

<footer class="page-footer">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-3">
				<!-- Logo et liens vers les réseaux sociaux -->
				<img style="margin: 0px; padding: 0px;" id="logo" src="logo.png" height="80" width="200" alt="logo">
				<ul class="site">
					<li>
						<a href="https://www.facebook.com/" target="_blank" rel="noreferrer"><img alt="Facebook" src="fb.png" style="margin: 0px; padding: 0px;" width="24" height="24" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
					</li>
					<li>
						<a href="https://www.instagram.com/" target="_blank" rel="noreferrer"><img alt="instagram" src="insta.png" style="margin: 0px; padding: 0px;" width="24" height="24" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
					</li>
					<li>
						<a href="https://www.youtube.com/" target="_blank" rel="noreferrer"><img alt="youtube" src="https://clipart-library.com/images/dc4LABqni.png" style="margin: 0px; padding: 0px;" width="24" height="20" decoding="async" data-nimg="1" loading="lazy" style="color:transparent"></a>
					</li>
				</ul>
			</div>
			<div class="col-lg-3" style="margin: 0px; padding: 0px; margin-left: 10px;">
				<!-- Informations additionnelles -->
				<h6 class="text-uppercase font-weight-bold">Information additionnelle</h6>
				<p style="text-align:justify;">
					Ce site utilise des cookies pour vous garantir la meilleure expérience. En poursuivant votre consultation, vous acceptez l’utilisation de ces cookies.
				</p>
			</div>
			<div class="col-lg-2" style="height:200px; background-color: transparent; margin-left: 30px;">
				<!-- Coordonnées de contact -->
				<h6 class="text-uppercase font-weight-bold">Contact</h6>
				<p>
					37, quai de Grenelle, 75015 Paris, France <br>
					sportify@webDynamique.ece.fr <br>
					+33 01 02 03 04 05 <br>
					+33 01 03 02 05 04
				</p>
			</div>
			<div class="col-lg-3" style="margin-left: 60px;">
				<!-- Carte Google Maps -->
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2143.576303287504!2d2.330437179343684!3d48.88009498207702!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66fa5dfd6b41f%3A0x1d20fbfc12fb96af!2sSpotify%20France%20SAS!5e0!3m2!1sfr!2sfr!4v1685467388920!5m2!1sfr!2sfr" width="250" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
			</div>
		</div>
		<div class="footer-copyright text-center">
			&copy; 2019 Copyright | Droit d'auteur:
			webDynamique.ece.fr
		</div>
	</div>
</footer>
<!-- Fenêtre modale pour afficher le CV -->
<div class="modal" id="cvModal" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">CV du coach</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="closeCVModal()">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
			</div>
		</div>
	</div>
</div>
</body>
</html>
</body>
</html>
